//doc event listeners
//doc event listeners
//doc event listeners

document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const errorMessageLogin = document.getElementById('error-message-login');
    const errorMessageSignup = document.getElementById('error-message-signup');
    const forgotPasswordLink = document.querySelector('.login-form .text a'); 

    loginForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        const jsonData = JSON.stringify({
            email: email,
            password: password
        });

        fetch('../API/UserWithSettings/login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: jsonData
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    errorMessageLogin.textContent = data.error;
                    errorMessageLogin.style.color = "red";
                } else if (data.message) {
                    if(data.tutorialStatus === "incomplete") {
                        let encryptedStartTutorial = encrypt("true");
                        window.location.href = `loggedin.html?startTutorial=${encryptedStartTutorial}`;
                    } else {
                        window.location.href = "loggedin.html";
                    }
                
                } else {
                    console.error('Unexpected response:', data);
                }
            })
            .catch(error => console.error('Error:', error));
    });

    signupForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const fullName = document.getElementById('signup-name').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;

        const jsonData = JSON.stringify({
            fullName: fullName,
            email: email,
            password: password
        });

        fetch('../API/UserWithSettings/signup.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: jsonData
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    errorMessageSignup.textContent = data.error;
                    errorMessageSignup.style.color = "red";
                } else if (data.success) {
                    if(data.tutorialStatus === "incomplete") {
                        let encryptedStartTutorial = encrypt("true");
                        window.location.href = `loggedin.html?startTutorial=${encryptedStartTutorial}`;
                    } else {
                        window.location.href = "loggedin.html";
                    }
                } else {
                    console.error('Unexpected response:', data);
                }
            })
            .catch(error => console.error('Error:', error));
    });

    // Added event listener for "Forgot password?"
    forgotPasswordLink.addEventListener('click', function (event) {
        event.preventDefault();

        const email = document.getElementById('login-email').value;

        if (email) {
            const jsonData = JSON.stringify({
                email: email
            });

            fetch('../API/UserWithSettings/forgotPassword.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: jsonData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        errorMessageLogin.textContent = data.error;
                        errorMessageLogin.style.color = "red";
                    } else if (data.success) {
                        errorMessageLogin.textContent = data.success;
                        errorMessageLogin.style.color = "green";
                    } else {
                        console.error('Unexpected response:', data);
                    }
                })
                .catch(error => console.error('Error:', error));
        } else {
            errorMessageLogin.textContent = "Please enter your email to reset password.";
            errorMessageLogin.style.color = "red";
        }
    });

    const tutorialButton = document.getElementById('tutorialer2');

    tutorialButton.addEventListener('click', function (event) {
        event.preventDefault();
        
        // Create a temporary full name, email, and password.
        // You should probably generate these more securely in a real application.
        const fullName = 'Temporary User';
        const email = `temp${Date.now()}@temp.com`;
        const password = 'TempPassword1';

        const jsonData = JSON.stringify({
            fullName: fullName,
            email: email,
            password: password,
            isTemporary: 1  // Indicate that this is a temporary account
        });

        fetch('../API/UserWithSettings/signup.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: jsonData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Could not create a temporary account: ' + data.error);
            } else if (data.success) {
                let encryptedStartTutorial = encrypt("true");
            window.location.href = `loggedin.html?startTutorial=${encryptedStartTutorial}`;
        
            } else {
                console.error('Unexpected response:', data);
            }
        })
        .catch(error => console.error('Error:', error));
    });
});

//for encryption
//for encryption
//for encryption


function encrypt(data) {
    let cipher = someEncryptionFunction('base64','your_secure_encryption_key');
    let encrypted = cipher.update(data, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

function decrypt(data) {
    let decipher = someDecryptionFunction('base64', 'your_secure_encryption_key');
    let decrypted = decipher.update(data, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

function someEncryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            return btoa(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}

function someDecryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            if (!data) {
                console.error("The data to decrypt is not available");
                return "";
            }
            return atob(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}
