//tutorial related stuff
//tutorial related stuff
//tutorial related stuff


function startTutorial(startStep = 0) {

    setTimeout(() => {
        let tutorial = introJs()
            .setOptions({
                steps: [
                    {
                        element: document.getElementById('fullName'),
                        intro: "You can change your name here. Some constraints apply.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('newPassword'),
                        intro: "You can change your password here, but you must input the old one first.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('oldPassword'),
                        intro: "Input your old password here. The same constraints apply as when you first created the password.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('reminderTiming'),
                        intro: "Input a positive integer here to set the number of minutes before which an email is sent for each task. Three emails will be sent per task.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('emailDecision'),
                        intro: "You can decide whether to send reminder emails or not.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('preferredList'),
                        intro: "Choose your default list here, which will be opened every time you log in or delete another list.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('recycleBinExpiry'),
                        intro: "Choose the number of days tasks will be deleted from the recycle bin if they are not restored.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('readonlyEmailSpan'),
                        intro: "This is your email, and it cannot be changed.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('readonlyPointsSpan'),
                        intro: "This displays your number of points, which can only be increased by completing tasks.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('messageDiv'),
                        intro: "Any errors that occur will be displayed here.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('youssef'),
                        intro: "We will click here to submit the changes!",
                        position: 'right'
                    },

                ],

                showBullets: false,
                skipLabel: 'Skip Tutorial',
                doneLabel: 'Next',
                exitOnOverlayClick: false,
                exitOnEsc: false,
                showStepNumbers: false,
                hidePrev: true,
                

            })
            .onbeforechange(function (targetElement) {

                if (targetElement.id === 'fullName') {
                    setTimeout(() => {
                        targetElement.value = 'John Doe'; // Input value into full name
                    }, 100);
                }
                // Go to id reminderTiming
                else if (targetElement.id === 'reminderTiming') {
                    setTimeout(() => {
                        targetElement.value = 10; // Input value into reminder timing
                    }, 100);
                }
                // Go to id emailDecision
                else if (targetElement.id === 'emailDecision') {
                    setTimeout(() => {
                        targetElement.value = 'send'; // Set value to send emails
                    }, 100);
                }
                // Go to id recycleBinExpiry
                else if (targetElement.id === 'recycleBinExpiry') {
                    setTimeout(() => {
                        targetElement.value = 1; // Set value for 15 days expiry
                    }, 100);
                }
                else if (targetElement.id === 'youssef') {
                    setTimeout(() => {
                        targetElement.click(); // Set value for 15 days expiry
                    }, 3000);
                }
            })

        if (startStep !== 0) {
            tutorial.goToStep(startStep);
        }

        tutorial.start();

        const checkStep = () => {
            const currentStep = tutorial._currentStep;
            const nextButton = document.querySelector('.introjs-nextbutton');
            const prevButton = document.querySelector('.introjs-prevbutton');

            // Logic for the last step (index 10)
            if (currentStep === tutorial._introItems.length - 1) {
                if (nextButton) nextButton.style.display = 'none';
                if (prevButton) prevButton.style.display = 'none';
            }
            // Logic for the first step (index 0)
            else if (currentStep === 0) {
                if (nextButton) nextButton.style.display = 'inline-block';
                if (prevButton) prevButton.style.display = 'none';
            }
            // Logic for the second step (index 1) and steps 3 to 10 (index 2 to 9)
            else {
                if (nextButton) nextButton.style.display = 'inline-block';
                if (prevButton) prevButton.style.display = 'inline-block';
            }
        };

        // Check the current step at the beginning
        checkStep();

        // Periodically check the step (e.g., every 300 milliseconds)
        const intervalId = setInterval(checkStep, 100);

        // Clear the interval when the tutorial exits
        tutorial.onexit(() => {
            clearInterval(intervalId);
            completeTutorial();
        });

    }, 200); // Your existing 200 ms delay
}

async function completeTutorial() {
    const settings = await fetchUserSettings();
    
    if (settings && settings.isTemporary === 1) {
        fetch('../API/UserWithSettings/deleteAccount.php')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else if (data.success) {
                    window.location.href = 'index.html';
                }
            })
            .catch(() => {
                alert('An error occurred while deleting the temporary account.');
            });
    } else {
        fetch('../API/UserWithSettings/completeTutorial.php', {
            method: 'POST'
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    window.location.href = window.location.href.split('?')[0];
                }
            })
            .catch(error => {
                alert('There was an error completing the tutorial.');
            });
    }
}





document.addEventListener("DOMContentLoaded", function () {
    const encryptedShouldStartTutorial = getURLParameter("startTutorial");
    const encryptedTutorialStep = getURLParameter("tutorialStep");

    const shouldStartTutorial = decrypt(encryptedShouldStartTutorial);
    const tutorialStep = decrypt(encryptedTutorialStep);

    if (shouldStartTutorial === "true") {
        if (tutorialStep) {
            startTutorial(Number(tutorialStep));
        } else {
            startTutorial();
        }
    }
});


function getURLParameter(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
}

async function fetchUserSettings() {
    const response = await fetch('../API/UserWithSettings/getSettings.php');
    const data = await response.json();
    return data;
}


//just to maintain the page scrolls and popups
//just to maintain the page scrolls and popups
//just to maintain the page scrolls and popups

(function () {
    "use strict";

    const select = (el, all = false) => {
        el = el.trim();
        if (all) {
            return [...document.querySelectorAll(el)];
        } else {
            return document.querySelector(el);
        }
    }

    let backtotop = select('.back-to-top');
    if (backtotop) {
        backtotop.classList.add('active');
    }
    let backtotop2 = select('.back-to-top2');
    if (backtotop2) {
        backtotop2.classList.add('active');
    }
})();



//handle popups
//handle popups
//handle popups


function toggleDivOne3(event) {
    var divOne = document.getElementById('divOne3');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        fetchArticleContent();
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }

    // Check if event exists before calling preventDefault
    if (event) {
        event.preventDefault();
    }
}

function handlePopupToggle() {
    // Check if the user is logged in
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, toggle the popup
                toggleDivOne3();
            } else {
                // If not logged in, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch(() => {
            alert('An error occurred. Please try again later.');
        });
}


//other functions
//other functions
//other functions

function fetchArticleContent() {
    fetch('../API/Articles/getArticle.php')
        .then(response => response.json())
        .then(data => {
            const articleContent = document.getElementById('articleContent');
            const errorMessage = document.getElementById('errorMessage');
            const getArticleButton = document.getElementById('getArticleButton');

            if (data.error) {
                errorMessage.textContent = data.error;
            } else {
                articleContent.value = data.article;
                errorMessage.textContent = '';
                // Handle userPoints
                if (data.userPoints && data.userPoints % 10 === 0) {
                    getArticleButton.style.background = "green";
                } else {
                    getArticleButton.style.background = "#550096"; // Set back to the default color if it's not divisible by 10
                }
            }
        })
        .catch(error => {
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.textContent = 'Failed to fetch article. Please try again later.';
        });
}

function fetchSettings() {
    let settingsData;  // Declare this variable to store the fetched data

    fetch('../API/UserWithSettings/getSettings.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                window.location.href = 'index.html';
                return;
            }

            // Assign values from the fetched JSON to the form fields
            document.getElementById('fullName').value = data.fullName;
            document.getElementById('readonlyEmailSpan').innerText = data.email;
            document.getElementById('readonlyPointsSpan').innerText = data.points;

            document.getElementById('reminderTiming').value = data.reminderTiming;

            settingsData = data;  // Store the fetched data in settingsData

            return populatePreferredListDropdown();
        })
        .then(() => {
            const preferredList = document.getElementById('preferredList');
            preferredList.value = settingsData.preferredList;  // Use settingsData here

            if (settingsData.emailDecision !== undefined) {
                document.getElementById('emailDecision').value = settingsData.emailDecision == 0 ? 'doNotSend' : 'send';
            }
            if (settingsData.recycleBinDecision !== undefined) {
                document.getElementById('recycleBinExpiry').value = settingsData.recycleBinDecision.toString();
            }

            // You can expand this logic for other fields as per your needs.
        })
        .catch(error => {
            console.log(error);
            alert('Failed to fetch settings. Please try again later.');
        });
}

function populatePreferredListDropdown() {
    return new Promise((resolve, reject) => {
        fetch('../API/Lists/getAllUserLists.php')
            .then(response => response.json())
            .then(data => {
                const preferredList = document.getElementById('preferredList');

                // Clear existing options
                preferredList.innerHTML = '';

                data.forEach(list => {
                    // Ignore lists with name recycleBin or CompletedTasksList
                    if (list.listName !== 'recycleBin' && list.listName !== 'CompletedTasksList') {
                        const option = document.createElement('option');
                        option.value = list.listID;
                        option.textContent = list.listName;
                        preferredList.appendChild(option);
                    }
                });
                resolve();
            })
            .catch(error => {
                console.error("Error in populatePreferredListDropdown:", error); // Improved error logging
                alert('Failed to fetch user lists. Please try again later.');
                reject();
            });
    });
}


function isLoggedIn(nextStep, alternateStep) {
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = nextStep;
            } else {
                window.location.href = alternateStep;
            }
        })
        .catch(() => {
            // handle any other errors here
            alert('An error occurred. Please try again later.');
        });
}

function updateSettings(data) {
    fetch('../API/UserWithSettings/updateSettings.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                messageDiv.style.color = '#8B0000';
                messageDiv.textContent = data.error;
            } else if (data.message) {
                messageDiv.style.color = 'white';
                messageDiv.textContent = data.message;

                setTimeout(() => {
                    let currentUrl = new URL(window.location.href);
                    let decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));
    
                    if (decryptedStartTutorial === "true") {
                        let newUrl = new URL('http://localhost/toDoListApp/todoListApp/FrontEnd/loggedin.html');
                        newUrl.searchParams.set('startTutorial', encrypt('true'));
                        newUrl.searchParams.set('tutorialStep', encrypt('36'));
                        window.location.href = newUrl.toString();
                    } else {
                        window.location.href = 'http://localhost/toDoListApp/todoListApp/FrontEnd/loggedin.html';
                    }
                }, 1000);
            }
        })
        .catch(() => {
            messageDiv.style.color = 'white';
            messageDiv.textContent = 'Failed to update settings. Please try again later.';
        });
}

//event listeners
//event listeners
//event listeners

document.addEventListener('DOMContentLoaded', function () {
    const logoHome = document.getElementById('logoHome');
    const homeDropdown = document.getElementById('homeDropdown');
    const signoutOption = document.getElementById('signoutOption');
    const deleteAccountOption = document.getElementById('deleteAccountOption');
    const aboutOption = document.getElementById('aboutOption');
    const settingsOption = document.getElementById('settingsOption');

    fetchSettings();
    fetchArticleContent();

    logoHome.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('loggedin.html', 'index.html');
    });

    homeDropdown.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('loggedin.html', 'index.html');
    });

    signoutOption.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('../API/UserWithSettings/logout.php')
            .then(response => response.json())
            .then(data => {
                if (data.success || data.error) {
                    window.location.href = 'index.html';
                }
            })
            .catch(() => {
                alert('An error occurred. Please try again later.');
            });
    });

    deleteAccountOption.addEventListener('click', (e) => {
        e.preventDefault();
        const confirmation = confirm('Do you really want to delete your account?');
        if (confirmation) {
            fetch('../API/UserWithSettings/deleteAccount.php')
                .then(response => response.json())
                .then(data => {
                    if (data.error === 'User not logged in.') {
                        window.location.href = 'index.html';
                    } else if (data.error) {
                        alert(data.error);
                    } else if (data.success) {
                        window.location.href = 'index.html';
                    }
                })
                .catch(() => {
                    alert('An error occurred. Please try again later.');
                });
        }
    });

    aboutOption.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('about.html', 'index.html');
    });

    settingsOption.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('settings.html', 'index.html');
    });



    const settingsForm = document.querySelector('.form3');
    const messageDiv = document.getElementById('messageDiv');

    settingsForm.addEventListener('submit', function (e) {
        e.preventDefault();

        let formData = {
            fullName: document.getElementById('fullName').value,
            reminderTiming: document.getElementById('reminderTiming').value,
            emailDecision: document.getElementById('emailDecision').value === 'send' ? 1 : 0,
            preferredList: document.getElementById('preferredList').value,
            recycleBinDecision: document.getElementById('recycleBinExpiry').value
        };

        const newPasswordValue = document.getElementById('newPassword').value;
        const oldPasswordValue = document.getElementById('oldPassword').value;

        if (newPasswordValue) {
            if (!oldPasswordValue) {
                messageDiv.style.color = '#8B0000';
                messageDiv.textContent = 'Old password is required to change password.';
                return;
            }

            // Check old password first
            fetch('../API/UserWithSettings/confirmPass.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ password: oldPasswordValue })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        messageDiv.style.color = '#8B0000';
                        messageDiv.textContent = data.error;
                    } else {
                        // Old password is correct, send new settings with new password
                        formData.password = newPasswordValue;
                        updateSettings(formData);
                    }
                })
                .catch(() => {
                    messageDiv.style.color = '#8B0000';
                    messageDiv.textContent = 'Failed to validate old password. Please try again later.';
                });
        } else {
            updateSettings(formData);
        }
    });

});

//for encryption
//for encryption
//for encryption


function encrypt(data) {
    let cipher = someEncryptionFunction('base64','your_secure_encryption_key');
    let encrypted = cipher.update(data, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

function decrypt(data) {
    let decipher = someDecryptionFunction('base64', 'your_secure_encryption_key');
    let decrypted = decipher.update(data, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

function someEncryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            return btoa(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}

function someDecryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            if (!data) {
                console.error("The data to decrypt is not available");
                return "";
            }
            return atob(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}

