let notificationQueue = [];

function showNotification(message) {
    // Push the message into the notification queue
    notificationQueue.push(message);

    // Check and show notifications if not already in progress
    if (notificationQueue.length === 1) {
        displayFromQueue();
    }
}

function displayFromQueue() {
    if (notificationQueue.length === 0) return;  // Nothing to show

    const notification = document.getElementById('notification');
    const message = notificationQueue[0];  // Get the first message
    notification.textContent = message;
    notification.style.display = 'block';

    setTimeout(() => {
        notification.style.display = 'none';
        notificationQueue.shift();  // Remove the displayed message

        // Introduce a delay before showing the next notification
        setTimeout(() => {
            displayFromQueue();  // Check for next notification
        }, 150);  // 0.15-second delay
    }, 4000);
}


function callServerScripts() {
    const scripts = [
        {
            url: '../API/deleteExpiredTask.php',
            handlers: {
                error: (data) => alert(data.error),
                message: (data) => { /* Do nothing */ },
                success: (data) => {
                    let message = null;

                    // If updatedTasks exists and has content, append it to the message
                    if (data.deletedTasks && data.deletedTasks.length > 0) {
                        // For simplicity, let's say we just append the number of updated tasks
                        message += ` ${data.deletedTasks.length} tasks were updated.`;
                    }

                    showNotification(message);
                }
            }
        },
        {
            url: '../API/sendEmail.php',
            handlers: {
                error: (data) => alert(data.error),
                message: (data) => { /* Do nothing */ },
                success: (data) => {
                    let message = data.success;

                    // If updatedTasks exists and has content, append it to the message
                    if (data.remindedTasks && data.remindedTasks.length > 0) {
                        data.remindedTasks.forEach(taskMessage => {
                            // Extract the task text and date assigned from the message
                            const taskMatch = taskMessage.match(/task '(.*?)' assigned on date (.*?) on list \d+ successfully\./);

                            if (taskMatch) {
                                const taskText = taskMatch[1];
                                const dateAssigned = taskMatch[2];

                                // Create a new message without the list ID
                                const newMessage = `Reminder email sent for task '${taskText}' assigned on date ${dateAssigned} successfully.`;
                                showNotification(newMessage);
                            }
                        });
                    } else {
                        showNotification(data.success);
                    }
                }

            }
        },
        {
            url: '../API/sessionTimeout.php',
            handlers: {
                error: (data) => alert(data.error),
                message: (data) => {
                    if (data.message === 'Session timed out. User logged out.') {
                        alert(data.message);
                        window.location.href = 'index.html';
                    }
                },
                success: (data) => {
                }
            }
        },
        {
            url: '../API/updateTaskRepeating.php',
            handlers: {
                error: (data) => alert(data.error),
                message: (data) => { /* Do nothing */ },
                success: (data) => {
                    let message = data.success;

                    // If updatedTasks exists and has content, append it to the message
                    if (data.updatedTasks && data.updatedTasks.length > 0) {
                        // For simplicity, let's say we just append the number of updated tasks
                        message += ` ${data.updatedTasks.length} tasks were updated.`;
                    }
                    showNotification(message);
                }

            }
        }
    ];

    scripts.forEach(script => {
        fetch(script.url)
            .then(response => response.json())
            .then(data => {
                console.log(`Response from ${script.url}:`, data);
                if (data.error && script.handlers.error) {
                    script.handlers.error(data);
                } else if (data.message && script.handlers.message) {
                    script.handlers.message(data);
                } else if (data.success && script.handlers.success) {
                    script.handlers.success(data);
                }
            })
            .catch(error => {
                console.error(`Error calling ${script.url}:`, error);
            });
    });
}

// Call the function immediately after defining it
callServerScripts();
// Call the function every 20 seconds
setInterval(callServerScripts, 20000);
