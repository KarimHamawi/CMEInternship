//tutorial related stuff
//tutorial related stuff
//tutorial related stuff


function startTutorial(startStep = 0) {

    setTimeout(() => {
        let tutorial = introJs()
            .setOptions({
                steps: [
                    {
                        element: document.getElementById('aboutOsas'),
                        intro: "You can read about the creation of this application in this section.",
                        position: 'right'
                    },
                    {
                        intro: "The article about the app's creation can still be accessed from here and the header as well."
                    },
                    {
                        element: document.getElementById('abouHussein'),
                        intro: "We will dropdown here to click on settings.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('settingsOption'),
                        intro: "We will click it to change our settings.",
                        position: 'right'
                    },

                ],

                showBullets: false,
                skipLabel: 'Skip Tutorial',
                doneLabel: 'Next',
                exitOnOverlayClick: false,
                exitOnEsc: false,
                showStepNumbers: false,
                hidePrev: true

            })
            .onbeforechange(function (targetElement) {
                if (targetElement.id === 'settingsOption') {
                    setTimeout(() => {
                        targetElement.click();
                    }, 3000);
                }
            })
        if (startStep !== 0) {
            tutorial.goToStep(startStep);
        }

        tutorial.start();
        const checkStep = () => {
            const currentStep = tutorial._currentStep;
            const nextButton = document.querySelector('.introjs-nextbutton');
            const prevButton = document.querySelector('.introjs-prevbutton');

            // Add logic for the last step
            if (nextButton && currentStep === tutorial._introItems.length - 1) {
                nextButton.style.display = 'none'; // Hide 'Next' button
            } else if (nextButton) {
                nextButton.style.display = 'inline-block'; // Show 'Next' button
            }

            // Add logic for steps 2 and 3 (remember that step index starts at 0)
            if (prevButton && (currentStep === 1 || currentStep === 2)) {
                prevButton.style.display = 'inline-block'; // Show 'Back' button
            } else if (prevButton) {
                prevButton.style.display = 'none'; // Hide 'Back' button
            }
        };

        // Check the current step at the beginning
        checkStep();

        // Periodically check the step (e.g., every 300 milliseconds)
        const intervalId = setInterval(checkStep, 100);

        // Clear the interval when the tutorial exits
        tutorial.onexit(() => {
            clearInterval(intervalId);
            completeTutorial();
        });
    }, 200); // 0.2-second delay
}

async function completeTutorial() {
    const settings = await fetchUserSettings();
    
    if (settings && settings.isTemporary === 1) {
        fetch('../API/UserWithSettings/deleteAccount.php')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else if (data.success) {
                    window.location.href = 'index.html';
                }
            })
            .catch(() => {
                alert('An error occurred while deleting the temporary account.');
            });
    } else {
        fetch('../API/UserWithSettings/completeTutorial.php', {
            method: 'POST'
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    window.location.href = window.location.href.split('?')[0];
                }
            })
            .catch(error => {
                alert('There was an error completing the tutorial.');
            });
    }
}





document.addEventListener("DOMContentLoaded", function () {
    const encryptedStartTutorial = getURLParameter("startTutorial");
    const encryptedTutorialStep = getURLParameter("tutorialStep");
    
    const shouldStartTutorial = decrypt(encryptedStartTutorial);
    const tutorialStep = decrypt(encryptedTutorialStep);

    if (shouldStartTutorial === "true") {
        if (tutorialStep) {
            startTutorial(Number(tutorialStep));
        } else {
            startTutorial();
        }
    }
});


function getURLParameter(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
}

async function fetchUserSettings() {
    const response = await fetch('../API/UserWithSettings/getSettings.php');
    const data = await response.json();
    return data;
}


//just to maintain the page scrolls and popups
//just to maintain the page scrolls and popups
//just to maintain the page scrolls and popups


(function () {
    "use strict";

    const select = (el, all = false) => {
        el = el.trim();
        if (all) {
            return [...document.querySelectorAll(el)];
        } else {
            return document.querySelector(el);
        }
    }

    let backtotop = select('.back-to-top');
    if (backtotop) {
        backtotop.classList.add('active');
    }
    let backtotop2 = select('.back-to-top2');
    if (backtotop2) {
        backtotop2.classList.add('active');
    }
})();

function toggleDivOne3(event) {
    var divOne = document.getElementById('divOne3');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        fetchArticleContent();
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }

    // Check if event exists before calling preventDefault
    if (event) {
        event.preventDefault();
    }
}

//handle popups
//handle popups
//handle popups

function handlePopupToggle() {
    // Check if the user is logged in
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, toggle the popup
                toggleDivOne3();
            } else {
                // If not logged in, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });

}

//functions used
//functions used
//functions used

function fetchArticleContent() {
    fetch('../API/Articles/getArticle.php')
        .then(response => response.json())
        .then(data => {
            const articleContent = document.getElementById('articleContent');
            const errorMessage = document.getElementById('errorMessage');
            const getArticleButton = document.getElementById('getArticleButton');

            if (data.error) {
                errorMessage.textContent = data.error;
            } else {
                articleContent.value = data.article;
                errorMessage.textContent = '';
                // Handle userPoints
                if (data.userPoints && data.userPoints % 10 === 0) {
                    getArticleButton.style.background = "green";
                } else {
                    getArticleButton.style.background = "#550096"; // Set back to the default color if it's not divisible by 10
                }
            }
        })
        .catch(error => {
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.textContent = 'Failed to fetch article. Please try again later.';
        });
}



function isLoggedIn(nextStep, alternateStep) {
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = nextStep;
            } else {
                window.location.href = alternateStep;
            }
        })
        .catch(() => {
            // handle any other errors here
            alert('An error occurred. Please try again later.');
        });
}

//doc event listeners
//doc event listeners
//doc event listeners

document.addEventListener('DOMContentLoaded', function () {
    const logoHome = document.getElementById('logoHome');
    const homeDropdown = document.getElementById('homeDropdown');
    const signoutOption = document.getElementById('signoutOption');
    const deleteAccountOption = document.getElementById('deleteAccountOption');
    const aboutOption = document.getElementById('aboutOption');
    const settingsOption = document.getElementById('settingsOption');

    fetchArticleContent();

    logoHome.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('loggedin.html', 'index.html');
    });

    homeDropdown.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('loggedin.html', 'index.html');
    });

    signoutOption.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('../API/UserWithSettings/logout.php')
            .then(response => response.json())
            .then(data => {
                if (data.success || data.error) {
                    window.location.href = 'index.html';
                }
            })
            .catch(() => {
                alert('An error occurred. Please try again later.');
            });
    });

    deleteAccountOption.addEventListener('click', (e) => {
        e.preventDefault();
        const confirmation = confirm('Do you really want to delete your account?');
        if (confirmation) {
            fetch('../API/UserWithSettings/deleteAccount.php')
                .then(response => response.json())
                .then(data => {
                    if (data.error === 'User not logged in.') {
                        window.location.href = 'index.html';
                    } else if (data.error) {
                        alert(data.error);
                    } else if (data.success) {
                        window.location.href = 'index.html';
                    }
                })
                .catch(() => {
                    alert('An error occurred. Please try again later.');
                });
        }
    });

    aboutOption.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('about.html', 'index.html');
    });

    settingsOption.addEventListener('click', (e) => {
    e.preventDefault();
    let currentUrl = new URL(window.location.href);

    let decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));

    if (decryptedStartTutorial === "true") {
        // Encrypt URL parameters
        let encryptedStartTutorial = encrypt("true");
        let encryptedTutorialStep = encrypt("0");

        // Create new URL with encrypted parameters
        let newUrl = `http://localhost/toDoListApp/todoListApp/FrontEnd/settings.html?startTutorial=${encryptedStartTutorial}&tutorialStep=${encryptedTutorialStep}`;
        window.location.href = newUrl;

    } else {
        isLoggedIn('settings.html', 'index.html');
    }
});


});

//for encryption
//for encryption
//for encryption


function encrypt(data) {
    let cipher = someEncryptionFunction('base64','your_secure_encryption_key');
    let encrypted = cipher.update(data, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

function decrypt(data) {
    let decipher = someDecryptionFunction('base64', 'your_secure_encryption_key');
    let decrypted = decipher.update(data, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

function someEncryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            return btoa(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}

function someDecryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            if (!data) {
                console.error("The data to decrypt is not available");
                return "";
            }
            return atob(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}
