//tutorial related stuff
//tutorial related stuff
//tutorial related stuff


function startTutorial(startStep = 0) {
    generatefirstTaskHTML();
    setTimeout(() => {
        let tutorial = introJs()
            .setOptions({
                steps: [
                    {
                        intro: "Welcome to Task Reminder! The goal of this application is to help you never skip a task again. Consider It your personal reminder. Whether you're at work, at home, or wherever, Task Reminder is here for you!"
                    },
                    {
                        element: document.getElementById('logoHome'),
                        intro: "This is the home logo. You can find it on all pages of the website and use it to return to the homepage.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('homeDropdown'),
                        intro: "This button serves a similar purpose as the home logo, providing you with quick navigation options. It's not redundant; it offers more than just a return to the home!",
                        position: 'right'
                    },
                    {
                        intro: "Keep in mind that trying any functionalities on any page will not work if the user is no longer logged in."
                    },
                    {
                        element: document.getElementById('lists-btn'),
                        intro: "With this dropdown, you can access any of your lists, including 'CompletedTasksList' and 'recycleBin'.",
                        position: 'right'
                    },
                    //6
                    {
                        element: document.getElementById('create-list-option'),
                        intro: "Want to create a new list? We've already created a default list for you! You can also add more lists from this option within the dropdown. Let's click this for you...",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('create-list-name-input'),
                        intro: "This is where you can name your list. Remember, the name cannot be 'CompletedTasksList', 'recycleBin', or be left empty. We named it for you!",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('create-sorting-pref-select'),
                        intro: "Here you can choose how to sort your tasks within the list, either by priority or by time.",
                        position: 'right'
                    },
                    //9
                    {
                        element: document.getElementById('createErrorMessage'),
                        intro: "If there are any issues while creating a list, they will be displayed here.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('createKafta'),
                        intro: "Finally, this is where you submit the form to create a list. Let's click this for you...",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('currentListName'),
                        intro: "The name of the accessed list is displayed here.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('delete-list-btn'),
                        intro: "This button deletes the list currently displayed on the page. It won't delete 'recycleBin', 'CompletedTasksList', or the last list you have other than these two and an alert will stop that from happening. Let's delete this list that we just made by clicking it. All the tasks that belong to it will be deleted forever, even the ones that are in the CompletedTasksList or the recycleBin!",
                        position: 'right'
                    },
                    {
                        intro: "We are back to our original default list. That is because we currently have it as our preferred list, so anytime we delete a list, we will go back to it. Deleting this list now will not work as previously explained."
                    },
                    //14
                    {
                        element: document.getElementById('update-list-btn'),
                        intro: "With this button's popup, you can rename the list currently displayed. You can also choose if it sorted by priority or time. It is very similar to the create list we just did, and the same constraits apply to the naming and sorting.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('list-name-input'),
                        intro: "Here's where we can update the list name, let's call it 'Best List'.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('createKafta1'),
                        intro: "Finally, this is where you submit the form to update a list. Let's click this for you to update our list name.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('getArticleButton'),
                        intro: "Once you've completed 10 tasks, this button will turn green. It shows you a self-improvement article to read. Points earned from tasks can be viewed in settings. If you delete a task, it doesn't count toward points, and restoring a task from 'CompletedTasksList' deducts the points earned. Let's click this button for you...",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('divOne3'),
                        intro: "This is the article you can read for self-improvement. We will now close this article for you...",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('add-task-btn'),
                        intro: "Use this button to add a task to the displayed list. Tasks created for the special lists do not work. Let's click this button for you to demonstrate how it works...",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('task-input'),
                        intro: "This is where you'll write your task. Keep in mind that it cannot be left empty or contain only spaces. We'll input a demo task for you shortly.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('priority-select'),
                        intro: "Here you can choose the priority of your task. The scale goes from 1 (highest priority) to 5 (lowest priority). It can also be used for sorting the list. We'll demonstrate by selecting a priority shortly.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('taskType-select'),
                        intro: "You can use this option to determine how the task will repeat. We'll demonstrate by choosing an option to repeat daily without weekends.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('date-assigned-input'),
                        intro: "This input allows you to schedule a task for the future. For demonstration, we'll pick a future date and time for you shortly.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('errorMessagetask1'),
                        intro: "If there are any errors during the task creation, they'll be displayed right here.",
                        position: 'right'
                    },
                    //24
                    {
                        element: document.getElementById('createTaskkafting'),
                        intro: "Lastly, this button will submit your new task. Let's click this for you to see how it works...",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('tasksArea'),
                        intro: "This is where your tasks will appear. You can review, update, and interact with your tasks here.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('firstTask'),
                        intro: "This is the task we just created for demonstration. Here you can see the details of your task. Clicking anywhere on the task will allow you to update it,you can also try completing or deleting it! Exactly how we created it in the first place and with the same constraints!",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('firstTask1'),
                        intro: "Clicking this button will mark this task as complete. It will be moved to the 'CompletedTasksList' unless it's a repeating task, in which case it will appear again. Completing tasks will also earn you points for unlocking articles. Click it to see what happens! However, you will have to click next on a few steps you already did after.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('firstTaskText'),
                        intro: "This is the content of the task we just created. It tells you what needs to be done.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('firstTaskText2'),
                        intro: "These are the additional details for the task, such as priority and time.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('firstTask2'),
                        intro: "Clicking this will delete the task and move it to the 'recycleBin'.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('search-input'),
                        intro: "This is where you can search for your tasks. Lets try to search for our tasks!",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('aboltiftish'),
                        intro: "Use this to highlight the next instance of the search term on the page.",
                        position: 'right'
                    },
                    {

                        intro: "Notifications will appear on the bottom right when an email is sent as a reminder for a task, a deleted task is expired in the recycle bin, or if a task is restored due to being a repeating task from the 'CompletedTasksList'.",

                    },
                    //34
                    {
                        element: document.getElementById('my-Account'),
                        intro: "This dropdown offers various account-related options: delete your account, sign out, go to settings, or navigate to the About section. Be careful when deleting your account, we pre-empted it with a warning if you opt to delete your account in case it was a mistake.",
                        position: 'right'
                    },
                    {
                        element: document.getElementById('aboutOption'),
                        intro: "We will opt for the about section now!",
                        position: 'right'
                    },
                    {
                        intro: "Note that the CompletedTasksList and the recycleBin behave the same way as other lists. However, tasks cannot be updated in them. Both of these lists also cannot be deleted or updated. Also, tasks completed in the CompletedTasksList are restored to its original list and points are deducted for it. Tasks Completed in the recycleBin are also restored to their list. Finally, tasks deleted in either of them are deleted forever."
                    },
                    {
                        intro: "Thats all folks! Enjoy the application!"
                    }




                ],
                showBullets: false,
                skipLabel: 'Skip Tutorial',
                doneLabel: 'Next',
                exitOnOverlayClick: false,
                exitOnEsc: false,
                showStepNumbers: false,
                hidePrev: true

            })
            .onbeforechange(function (targetElement) {
                if (targetElement.id === 'create-list-option') {
                    setTimeout(() => {
                        handlePopupToggle5();
                    }, 100);
                } else if (targetElement.id === 'create-list-name-input') {
                    setTimeout(() => {
                        targetElement.value = 'My First List';
                    }, 10);
                } else if (targetElement.id === 'getArticleButton') {

                    setTimeout(() => {
                        targetElement.click();
                    }, 500);
                } else if (targetElement.id === 'add-task-btn') {

                    setTimeout(() => {
                        targetElement.click();
                        toggleDivOne3();

                    }, 100);
                } else if (targetElement.id === 'createKafta') {
                    setTimeout(() => {
                        targetElement.click();
                    }, 3000);
                }
                else if (targetElement.id === 'delete-list-btn') {
                    setTimeout(() => {
                        targetElement.click();
                    }, 15000);
                }
                else if (targetElement.id === 'update-list-btn') {
                    setTimeout(() => {
                        handlePopupToggle2();
                    }, 500);
                }
                else if (targetElement.id === 'list-name-input') {
                    setTimeout(() => {
                        targetElement.value = 'Best List';
                    }, 500);
                }
                else if (targetElement.id === 'createKafta1') {
                    setTimeout(() => {
                        targetElement.click();
                    }, 3000);
                }
                else if (targetElement.id === 'task-input') {
                    setTimeout(() => {
                        targetElement.value = 'Do this please!';
                    }, 200);
                } else if (targetElement.id === 'priority-select') {
                    setTimeout(() => {
                        targetElement.value = '2';
                    }, 200);
                } else if (targetElement.id === 'taskType-select') {
                    setTimeout(() => {
                        targetElement.value = '2';
                    }, 200);
                } else if (targetElement.id === 'date-assigned-input') {

                    setTimeout(() => {
                        targetElement.value = '2040-08-22T17:00';
                    }, 200);

                } else if (targetElement.id === 'createTaskkafting') {
                    setTimeout(() => {
                        targetElement.click();
                    }, 3000);
                }
                else if (targetElement.id === 'search-input') {
                    setTimeout(() => {
                        targetElement.value = 'Do this please!';
                        handleSearchInputEvent();
                    }, 500);
                }
                else if (targetElement.id === 'aboltiftish') {
                    setTimeout(() => {
                        handleSearchIconClick();
                        setTimeout(() => {
                            handleSearchIconClick();
                            setTimeout(() => {
                                handleSearchIconClick();
                            }, 200);
                        }, 200);
                    }, 500);
                }
                else if (targetElement.id === 'aboutOption') {
                    setTimeout(() => {
                        targetElement.click();
                    }, 3000);
                }
            })

        if (startStep !== 0) {
            tutorial.goToStep(startStep);
        }

        tutorial.start();
        const checkStep = () => {
            const currentStep = tutorial._currentStep;
            const nextButton = document.querySelector('.introjs-nextbutton');
            const prevButton = document.querySelector('.introjs-prevbutton');

            const stepSettings = [
                'next',          // Step 1
                'both',          // Step 2
                'both',          // Step 3
                'both',          // Step 4
                'both',          // Step 5
                'next',          // Step 6
                'next',          // Step 7
                'both',          // Step 8
                'both',          // Step 9
                'none',          // Step 10
                'next',          // Step 11
                'none',          // Step 12
                'next',          // Step 13
                'next',          // Step 14
                'next',          // Step 15
                'none',          // Step 16
                'next',          // Step 17
                'next',          // Step 18
                'next',          // Step 19
                'next',          // Step 20
                'both',          // Step 21
                'both',          // Step 22
                'both',          // Step 23
                'both',          // Step 24
                'none',          // Step 25
                'next',          // Step 26
                'both',          // Step 27
                'both',          // Step 28
                'both',          // Step 29
                'both',          // Step 30
                'both',          // Step 31
                'both',          // Step 32
                'both',          // Step 33
                'both',          // Step 34
                'both',           // Step 35
                'none',           // Step 36
                'next',           // Step 37
                'next',           // Step 38
            ];

            const setting = stepSettings[currentStep];

            if (setting === 'both') {
                if (nextButton) nextButton.style.display = 'inline-block';
                if (prevButton) prevButton.style.display = 'inline-block';
            } else if (setting === 'next') {
                if (nextButton) nextButton.style.display = 'inline-block';
                if (prevButton) prevButton.style.display = 'none';
            } else if (setting === 'none') {
                if (nextButton) nextButton.style.display = 'none';
                if (prevButton) prevButton.style.display = 'none';
            }
        };

        checkStep();

        const intervalId = setInterval(checkStep, 100);

        tutorial.onexit(() => {
            clearInterval(intervalId);
            completeTutorial();
        });

    }, 200); // Existing 200ms delay
}


async function completeTutorial() {
    const settings = await fetchUserSettings();
    
    if (settings && settings.isTemporary === 1) {
        fetch('../API/UserWithSettings/deleteAccount.php')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else if (data.success) {
                    window.location.href = 'index.html';
                }
            })
            .catch(() => {
                alert('An error occurred while deleting the temporary account.');
            });
    } else {
        fetch('../API/UserWithSettings/completeTutorial.php', {
            method: 'POST'
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    window.location.href = window.location.href.split('?')[0];
                }
            })
            .catch(error => {
                alert('There was an error completing the tutorial.');
            });
    }
}





document.addEventListener("DOMContentLoaded", function () {
    const encryptedShouldStartTutorial = getURLParameter("startTutorial");
    const encryptedTutorialStep = getURLParameter("tutorialStep");

    const shouldStartTutorial = decrypt(encryptedShouldStartTutorial);
    const tutorialStep = decrypt(encryptedTutorialStep);

    if (shouldStartTutorial === "true") {
        if (tutorialStep) {
            startTutorial(Number(tutorialStep));
        } else {
            startTutorial();
        }
    }
});


//generated only when signup or repeating tutorial for the demo
async function generatefirstTaskHTML() {
    // Define the task to be created
    const newTask = {
        taskText: "Do this please!",
        prio: 1,
        type: 0,
    };

    try {
        // Fetch and check the last created task
        const response = await fetch('../API/Tasks/getLastCreatedTask.php');
        const lastTaskData = await response.json();

        if (lastTaskData.success) {
            const lastTask = lastTaskData.task;

            // If the task is a duplicate, delete it
            if (newTask.taskText === lastTask.taskText &&
                newTask.prio === lastTask.prio &&
                newTask.type === lastTask.type) {

                console.log("Duplicate task found. Deleting old task...");

                // Delete the old task
                const payload = {
                    taskID: lastTask.taskID
                };
                const deleteResponse = await fetch('../API/Tasks/deleteTask2.php', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload)
                });

                const deleteData = await deleteResponse.json();

                if (!deleteData.success) {
                    // Log the error if "success" is false
                    console.error('Error from deleteTask:', deleteData.error || 'Unknown error');
                    return;  // Stop the function here if deletion failed
                }
            }
        }

        // If code reaches here, it means no duplicate was found
        const currentDate = new Date();
        currentDate.setMinutes(currentDate.getMinutes() + 17);

        const formattedDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
        const formattedTime = `${String(currentDate.getHours()).padStart(2, '0')}:${String(currentDate.getMinutes()).padStart(2, '0')}`;
        const dateAssignedInput = `${formattedDate}T${formattedTime}`;

        const taskPayload = {
            taskText: "Do this please!",
            prio: 1,
            type: 0,
            dateAssigned: dateAssignedInput
        };

        const createResponse = await fetch('../API/Tasks/createSingleTask.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(taskPayload)
        });

        const createData = await createResponse.json();

        if (createData.success) {
            fetch('../API/Tasks/getLastCreatedTask.php')
                .then(response => response.json())
                .then(taskData => {
                    if (taskData.success) {
                        const task = taskData.task;
                        const taskID = task.taskID || "defaultTaskID";
                        let html = `
                        <div class="karim" data-task-id="${taskID}" id="firstTask" draggable="false">
                          <div class="dup-row">
                              <div class="dup-col-lg dup-d-flex dup-justify-content-center dup-align-items-center custom-icon icons" draggable="false" id="firstTask1">
                                  <div class="icon-wrapper check-icon">
                                      <i class="bi bi-check-lg custom-icon"></i>
                                  </div>
                              </div>
                              <div class="dup-col-lg1 dup-d-flex dup-justify-content-center dup-align-items-center" >
                                  <div class="text-container">
                                      <p class="dup-text-center" id="firstTaskText">${task.taskText}</p>
                                      <div class="text-container">
                                          <p class="dup-text-center2" id="firstTaskText2">
                                              Priority: ${task.prio}&nbsp;&nbsp;&nbsp;&nbsp;Type: ${getTypeText(task.type)}&nbsp;&nbsp;&nbsp;&nbsp;Assigned Date: ${task.dateAssigned}
                                          </p>
                                      </div>
                                  </div>
                              </div>
                              <div class="dup-col-lg dup-d-flex dup-justify-content-center dup-align-items-center custom-icon2 icons" draggable="false" id="firstTask2">
                                  <div class="icon-wrapper trash-icon">
                                      <i class="bi bi-trash3 custom-icon2"></i>
                                  </div>
                              </div>
                          </div>
                      </div>
                    `;
                        document.querySelector('.wrapperali').insertAdjacentHTML('afterend', html);
                    }
                    else {
                        // Log the error if "success" is false
                        console.error('Error from getLastCreatedTask:', taskData.error || 'Unknown error');
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    alert('An error occurred while fetching the last task. Please try again.');
                });
        } else {
            // Log the error if "success" is false
            console.error('Error from createSingleTask:', data.error || 'Unknown error');
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}


function getURLParameter(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
}

async function fetchUserSettings() {
    const response = await fetch('../API/UserWithSettings/getSettings.php');
    const data = await response.json();
    return data;
}

//just to maintain the page scrolls and popups
//just to maintain the page scrolls and popups
//just to maintain the page scrolls and popups

(function () {
    "use strict";

    const select = (el, all = false) => {
        el = el.trim();
        if (all) {
            return [...document.querySelectorAll(el)];
        } else {
            return document.querySelector(el);
        }
    }

    let backtotop = select('.back-to-top');
    if (backtotop) {
        backtotop.classList.add('active');
    }
    let backtotop2 = select('.back-to-top2');
    if (backtotop2) {
        backtotop2.classList.add('active');
    }
})();



function toggleDivOne() {
    var divOne = document.getElementById('divOne');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }

}

function toggleDivOne2(event) {
    var divOne = document.getElementById('divOne2');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }
    if (event) event.preventDefault();
}


function toggleDivOne3(event) {
    var divOne = document.getElementById('divOne3');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        fetchArticleContent();
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }

    // Check if event exists before calling preventDefault
    if (event) {
        event.preventDefault();
    }
}

function toggleDivOne5(event) {
    var divOne = document.getElementById('divOne5');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }
    if (event) event.preventDefault();
}

function toggleDivOne6(event) {
    var divOne = document.getElementById('divOne6');
    if (divOne.style.visibility === 'visible') {
        divOne.style.visibility = 'hidden';
        divOne.style.opacity = 0;
        divOne.style.pointerEvents = 'none';
    } else {
        divOne.style.visibility = 'visible';
        divOne.style.opacity = 1;
        divOne.style.pointerEvents = 'auto';
    }
    if (event) event.preventDefault();
}


function handlePopupToggle2() {
    // First, check if the user is logged in.
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, fetch data from getOneList.php
                return fetch('../API/Lists/getOneList.php')
                    .then(response => response.json())
                    .then(listData => {
                        if (listData.error) {
                            if (listData.error === 'User not logged in.') {
                                window.location.href = 'index.html';
                            } else {
                                alert(listData.error);
                            }
                        } else {
                            // Populate the form with listData
                            document.getElementById('list-name-input').value = listData.listName;
                            document.getElementById('sorting-pref-select').value = listData.sortingPref.toString();

                            // Show the popup
                            toggleDivOne2();
                        }
                    });
            } else {
                // If not logged in based on isloggedin.php, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}


function handlePopupToggle1() {
    // Check if the user is logged in
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, toggle the popup
                toggleDivOne();
            } else {
                // If not logged in, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });

}

function handlePopupToggle5() {
    // Check if the user is logged in for list
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, toggle the popup
                toggleDivOne5();
            } else {
                // If not logged in, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}

function handlePopupToggle6(taskID) {
    // Check if the user is logged in for task
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, fetch data for the task using the taskID
                fetchTaskData(taskID);
                toggleDivOne6(); // Assuming you still want to toggle the popup in this function
            } else {
                // If not logged in, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}

function handlePopupToggle() {
    // Check if the user is logged in
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, toggle the popup
                toggleDivOne3();
            } else {
                // If not logged in, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });

}

// used functions
// used functions
// used functions

function fetchArticleContent() {
    fetch('../API/Articles/getArticle.php')
        .then(response => response.json())
        .then(data => {
            const articleContent = document.getElementById('articleContent');
            const errorMessage = document.getElementById('errorMessage');
            const getArticleButton = document.getElementById('getArticleButton');

            if (data.error) {
                errorMessage.textContent = data.error;
            } else {
                articleContent.value = data.article;
                errorMessage.textContent = '';
                // Handle userPoints
                if (data.userPoints && data.userPoints % 10 === 0) {
                    getArticleButton.style.background = "green";
                } else {
                    getArticleButton.style.background = "#550096"; // Set back to the default color if it's not divisible by 10
                }
            }
        })
        .catch(error => {
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.textContent = 'Failed to fetch article. Please try again later.';
        });
}


//handling submits of popup forms
//handling submits of popup forms
//handling submits of popup forms

function handleSubmit(event) {
    event.preventDefault(); // prevent the form from submitting in the traditional way

    let listName = document.getElementById('list-name-input').value;
    let sortingPref = document.getElementById('sorting-pref-select').value;

    // Create the payload for the fetch request
    const payload = {
        listName: listName,
        sortingPref: sortingPref
    };

    // Make a request to updateList.php
    fetch('../API/Lists/updateList.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            const errorMessageElement = document.getElementById('errorMessage');

            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    errorMessageElement.style.color = 'red';
                    errorMessageElement.textContent = data.error;
                }
            } else if (data.success) {
                errorMessageElement.style.color = 'green';
                errorMessageElement.textContent = data.success;

                setTimeout(() => {
                    let currentUrl = new URL(window.location.href);
                    const decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));
                
                    if (decryptedStartTutorial === "true") {
                        currentUrl.searchParams.set("tutorialStep", encrypt("16"));
                        window.location.href = currentUrl.toString();
                    } else {
                        location.reload();
                    }
                }, 250);
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}

function handleTaskSubmit(event) {
    event.preventDefault();

    const taskInput = document.getElementById('task-input').value;
    const prioritySelect = document.getElementById('priority-select').value;
    const taskTypeSelect = document.getElementById('taskType-select').value;
    const dateAssignedInput = document.getElementById('date-assigned-input').value;

    const payload = {
        taskText: taskInput,
        prio: prioritySelect,
        type: taskTypeSelect,
        dateAssigned: dateAssignedInput
    };

    fetch('../API/Tasks/createSingleTask.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            const errorMessageElement = document.getElementById('errorMessagetask1');

            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    errorMessageElement.style.color = 'red';
                    errorMessageElement.textContent = data.error;
                }
            } else if (data.success) {
                errorMessageElement.style.color = 'green';
                errorMessageElement.textContent = data.success;

                setTimeout(() => {
                    let currentUrl = new URL(window.location.href);
                    const decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));
                
                    if (decryptedStartTutorial === "true") {
                        currentUrl.searchParams.set("tutorialStep", encrypt("25"));
                        window.location.href = currentUrl.toString();
                    } else {
                        location.reload();
                    }
                }, 250);
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}



function handleCreateSubmit(event) {
    event.preventDefault(); // prevent the form from submitting in the traditional way

    let listName = document.getElementById('create-list-name-input').value;
    let sortingPref = document.getElementById('create-sorting-pref-select').value;

    // Create the payload for the fetch request
    const payload = {
        listName: listName,
        sortingPref: sortingPref
    };

    // Make a request to createList.php
    fetch('../API/Lists/createList.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            const createErrorMessageElement = document.getElementById('createErrorMessage');

            if (data.error) {
                createErrorMessageElement.textContent = data.error;
                createErrorMessageElement.style.color = 'red';
            } else if (data.success) {
                createErrorMessageElement.style.color = 'green';
                createErrorMessageElement.textContent = data.success;

                setTimeout(() => {
                    let currentUrl = new URL(window.location.href);
                    const decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));
                
                    if (decryptedStartTutorial === "true") {
                        currentUrl.searchParams.set("tutorialStep", encrypt("11"));
                        window.location.href = currentUrl.toString();
                    } else {
                        location.reload();
                    }
                }, 250);

            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}

function handleUpdateTaskSubmit(event) {
    event.preventDefault();

    const formElement = event.currentTarget;
    const taskID = formElement.getAttribute('data-task-id'); // Retrieve the taskID from the form

    const taskInput = document.getElementById('update-task-input').value;
    const prioritySelect = document.getElementById('update-priority-select').value;
    const taskTypeSelect = document.getElementById('update-taskType-select').value;
    const dateAssignedInput = document.getElementById('update-date-assigned-input').value;


    const payload = {
        taskText: taskInput,
        prio: prioritySelect,
        type: taskTypeSelect,
        dateAssigned: dateAssignedInput,
        taskID: taskID
    };

    fetch('../API/Tasks/updateTask.php', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.text())  // Change this to text to see the raw response
        .then(text => {
            console.log("Raw Response:", text);  // Log the raw response
            return JSON.parse(text);  // Manually try to parse the response to JSON
        })
        .then(data => {
            const errorMessageElement = document.getElementById('update-errorMessagetask');

            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    errorMessageElement.style.color = 'red';
                    errorMessageElement.textContent = data.error;
                }
            } else if (data.success) {
                errorMessageElement.style.color = 'green';
                errorMessageElement.textContent = data.success;

                setTimeout(() => {
                    location.reload();
                }, 250);
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });
}


//other used functions
//other used functions
//other used functions

function setCurrentListName(listName) {
    const listNameElement = document.getElementById('currentListName');
    if (listNameElement) {
        listNameElement.innerText = listName;
    }
}


function isLoggedIn(nextStep, alternateStep) {
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = nextStep;
            } else {
                window.location.href = alternateStep;
            }
        })
        .catch(() => {
            // handle any other errors here
            alert('An error occurred. Please try again later.');
        });
}

// Fetch lists from the server
function fetchUserLists() {
    fetch('../API/Lists/getAllUserLists.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                // Redirect to index.html if there's an error in the response
                window.location.href = 'index.html';
            } else {
                populateDropdown(data);
            }
        })
        .catch(error => {
            console.error("Fetch error:", error);
            window.location.href = 'index.html';
        });
}

// Populate the dropdown using the provided lists
function populateDropdown(lists) {
    const dropdown = document.getElementById('dropdown-lists');

    // Clear existing items except the 'Create List' option
    while (dropdown.firstChild && dropdown.firstChild.id !== 'create-list-option') {
        dropdown.removeChild(dropdown.firstChild);
    }

    // Populate the dropdown with new list items
    lists.forEach(list => {
        const li = document.createElement('li');
        li.innerHTML = `<a href="#" data-list-id="${list.listID}" onclick="handleListClick(${list.listID})">${list.listName}</a>`;
        dropdown.insertBefore(li, document.getElementById('create-list-option'));
    });
}

// Handle the click event for a list item
function handleListClick(listID) {
    console.log("Selected List ID:", listID);
    // Check if the user is logged in
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                // Redirect to index.html if there's an error in the response
                window.location.href = 'index.html';
            } else {
                // If user is logged in, call accessList.php with the list ID
                accessList(listID);

            }
        })
        .catch(error => {
            console.error("Fetch error:", error);
            window.location.href = 'index.html';
        });
}


function accessList(listID) {
    fetch('../API/Lists/accessList.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ listID: listID })  // Sending listID as JSON in the body
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    alert(data.error);
                }
            } else if (data.message) {
                // Refresh the page
                location.reload();
            }
        })
        .catch(error => {
            console.error("Fetch error:", error);
            alert('An unexpected error occurred. Please try again.');
        });
}


function deleteList() {
    fetch('../API/Lists/deleteList.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    alert(data.error);
                }
            } else if (data.success) {

                let currentUrl = new URL(window.location.href);
                const decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));
                
                if (decryptedStartTutorial === "true") {
                    currentUrl.searchParams.set("tutorialStep", encrypt("13"));
                    window.location.href = currentUrl.toString();
                } else {
                    location.reload();
                }

            }
        })
        .catch(error => {
            console.error("Fetch error:", error);
            alert('An unexpected error occurred. Please try again.');
        });
}


function listname() {

    // Fetch the current accessed list's details
    fetch('../API/UserWithSettings/isloggedin.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // If the user is logged in, fetch data from getOneList.php
                return fetch('../API/Lists/getOneList.php')
                    .then(response => response.json())
                    .then(listData => {
                        if (listData.error) {
                            if (listData.error === 'User not logged in.') {
                                window.location.href = 'index.html';
                            } else {
                                alert(listData.error);
                            }
                        } else {
                            // Set the list name to the appropriate div
                            setCurrentListName(listData.listName);
                        }
                    });
            } else {
                // If not logged in based on isloggedin.php, redirect to index.html
                window.location.href = 'index.html';
            }
        })
        .catch((error) => {
            console.error("Fetch error:", error);
            alert('An error occurred. Please check the console for more details.');
        });

}


//event listeners
//event listeners
//event listeners

document.addEventListener('DOMContentLoaded', function () {

    const logoHome = document.getElementById('logoHome');
    const homeDropdown = document.getElementById('homeDropdown');
    const signoutOption = document.getElementById('signoutOption');
    const deleteAccountOption = document.getElementById('deleteAccountOption');
    const aboutOption = document.getElementById('aboutOption');
    const settingsOption = document.getElementById('settingsOption');
    const deletelistbtn = document.getElementById('delete-list-btn');


    logoHome.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('loggedin.html', 'index.html');
    });

    // Call the fetch function initially to populate the dropdown
    fetchUserLists();
    fetchArticleContent();

    homeDropdown.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn('loggedin.html', 'index.html');
    });

    signoutOption.addEventListener('click', (e) => {
        e.preventDefault();
        fetch('../API/UserWithSettings/logout.php')
            .then(response => response.json())
            .then(data => {
                if (data.success || data.error) {
                    window.location.href = 'index.html';
                }
            })
            .catch(() => {
                alert('An error occurred. Please try again later.');
            });
    });

    deleteAccountOption.addEventListener('click', (e) => {
        e.preventDefault();
        const confirmation = confirm('Do you really want to delete your account?');
        if (confirmation) {
            fetch('../API/UserWithSettings/deleteAccount.php')
                .then(response => response.json())
                .then(data => {
                    if (data.error === 'User not logged in.') {
                        window.location.href = 'index.html';
                    } else if (data.error) {
                        alert(data.error);
                    } else if (data.success) {
                        window.location.href = 'index.html';
                    }
                })
                .catch(() => {
                    alert('An error occurred. Please try again later.');
                });
        }
    });

    aboutOption.addEventListener('click', (e) => {
        e.preventDefault();
        let currentUrl = new URL(window.location.href);
        const decryptedStartTutorial = decrypt(currentUrl.searchParams.get("startTutorial"));
    
        if (decryptedStartTutorial === "true") {
            let newUrl = "http://localhost/toDoListApp/todoListApp/FrontEnd/about.html";
            let url = new URL(newUrl);
            url.searchParams.set("startTutorial", encrypt("true"));
            url.searchParams.set("tutorialStep", encrypt("0"));
            window.location.href = url.toString();
        } else {
            isLoggedIn('about.html', 'index.html');
        }
    });
    


    settingsOption.addEventListener('click', (e) => {
        e.preventDefault();

        isLoggedIn('settings.html', 'index.html');

    });


    deletelistbtn.addEventListener('click', function (event) {
        event.preventDefault(); // prevent default action

        // Check if the user is logged in
        fetch('../API/UserWithSettings/isloggedin.php')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    // Redirect to index.html if there's an error in the response
                    window.location.href = 'index.html';
                } else {
                    // If user is logged in, call deleteList.php
                    deleteList();
                }
            })
            .catch(error => {
                console.error("Fetch error:", error);
                window.location.href = 'index.html';
            });
    });

    fetch('../API/Lists/getOneList.php')
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            console.log("Error:", data.error);
        } else {
            // IDs of elements to hide or show
            const elementIDs = [
                'delete-list-btn',
                'update-list-btn',
                'add-task-btn',
                'add-task-btnkafta'
            ];

            // Check if the list name is "recycleBin" or "CompletedTasksList"
            if (data.listName === 'recycleBin' || data.listName === 'CompletedTasksList') {
                // Hide the elements
                elementIDs.forEach(id => {
                    const element = document.getElementById(id);
                    if (element) {
                        element.style.setProperty('display', 'none', 'important');
                    }
                });
            } else {
                // Show the elements if they were previously hidden
                elementIDs.forEach(id => {
                    const element = document.getElementById(id);
                    if (element) {
                        element.style.removeProperty('display');
                    }
                });
            }
        }
    })
    .catch(error => {
        console.error("Fetch error:", error);
    });


        
});

document.addEventListener('DOMContentLoaded', (event) => {
    listname();
    fetchTasks();
});


//CODE FOR ANIMATIONS OF TASKS
//CODE FOR ANIMATIONS OF TASKS
//CODE FOR ANIMATIONS OF TASKS
//CODE FOR ANIMATIONS OF TASKS


//helper
function resetLockedElementsAndAnimations() {
    const activeIcon = document.querySelector('.icon-wrapper-active');
    const activeKarim = document.querySelector('.karim-active');

    if (activeIcon) {
        activeIcon.classList.remove('icon-wrapper-active');
    }

    if (activeKarim) {
        activeKarim.classList.remove('karim-active');
    }

    lockedInElement = null;  // Reset the locked element
}

//rest

let lockedInElement = null;

document.querySelector('.container.lafta').addEventListener('mousedown', function (event) {
    const icon = event.target.closest('.icon-wrapper');
    if (icon) {
        icon.classList.add('icon-wrapper-active');
        lockedInElement = 'icon';
        return;
    }

    const karim = event.target.closest('.karim');
    if (karim) {
        karim.classList.add('karim-active');
        lockedInElement = 'karim';
    }
});



document.addEventListener('mouseup', function (event) {
    // Early exit if no element was locked in during mousedown
    if (!lockedInElement) return;

    const closestKarim = event.target.closest('.karim');

    // Handle the active icon actions
    if (lockedInElement === 'icon') {
        const activeIcon = document.querySelector('.icon-wrapper-active');

        if (!activeIcon) return; // Safety check

        const taskID = closestKarim.getAttribute('data-task-id');
        activeIcon.classList.remove('icon-wrapper-active');

        // Check the type of icon based on the class of activeIcon or any of its children
        if (activeIcon.classList.contains('check-icon') || activeIcon.querySelector('.bi-check-lg')) {
            handleTaskCompletion(taskID);
        } else if (activeIcon.classList.contains('trash-icon') || activeIcon.querySelector('.bi-trash3')) {
            handleTaskDeletion(taskID);
        }
    }

    // Handle the actions for the activeKarim
    if (lockedInElement === 'karim') {
        const activeKarim = document.querySelector('.karim-active');

        if (!activeKarim) return; // Safety check

        const taskID = activeKarim.getAttribute('data-task-id');
        const formElement = document.querySelector('.form32');
        formElement.setAttribute('data-task-id', taskID);
        activeKarim.classList.remove('karim-active');
        handlePopupToggle6(taskID);
    }

    // Reset the locked element after processing
    lockedInElement = null;
});





document.querySelector('.container.lafta').addEventListener('mouseleave', function (event) {
    resetLockedElementsAndAnimations();
});





// CODE FOR UPDATE TASKS FUNCTIONALITIES AND MAKING TASKS
// CODE FOR UPDATE TASKS FUNCTIONALITIES AND MAKING TASKS
// CODE FOR UPDATE TASKS FUNCTIONALITIES AND MAKING TASKS



function generateTaskHTML(tasks) {
    let html = '';
    tasks.forEach(task => {
        html += `
          
                <div class="karim" data-task-id="${task.taskID}" id="${task.taskID}" draggable="false">

                  <div class="dup-row">
                      <!-- Left icon -->
                      <div class="dup-col-lg dup-d-flex dup-justify-content-center dup-align-items-center custom-icon icons" draggable="false">
                          <div class="icon-wrapper check-icon">
                              <i class="bi bi-check-lg custom-icon"></i>
                          </div>
                      </div>
                      <!-- Text containers -->
                      <div class="dup-col-lg1 dup-d-flex dup-justify-content-center dup-align-items-center">
                          <div class="text-container">
                              <p class="dup-text-center">${task.taskText}</p>
                              <div class="text-container">
                                  <p class="dup-text-center2">
                                      Priority: ${task.prio}&nbsp;&nbsp;&nbsp;&nbsp;Type: ${getTypeText(task.type)}&nbsp;&nbsp;&nbsp;&nbsp;Assigned Date: ${task.dateAssigned}
                                  </p>
                              </div>
                          </div>
                      </div>
                      <!-- Right icon -->
                      <div class="dup-col-lg dup-d-flex dup-justify-content-center dup-align-items-center custom-icon2 icons" draggable="false">
                          <div class="icon-wrapper trash-icon">
                              <i class="bi bi-trash3 custom-icon2"></i>
                          </div>
                      </div>
                  </div>
              </div>
          
      `;

    });
    document.querySelector('.wrapperali').insertAdjacentHTML('afterend', html);

}






//helpers

function getTypeText(type) {
    switch (type) {
        case 0: return 'Doesn\'t Repeat';
        case 1: return 'Repeat Daily';
        case 2: return 'Repeat Daily Without Weekends';
        case 3: return 'Repeating Weekly';
        case 4: return 'Repeating Monthly';
        case 5: return 'Repeating Yearly';
        default: return 'Unknown Type';
    }
}

//to sort

function sortTasks(tasks, sortingPref) {
    tasks.sort((a, b) => {
        // Sorting primarily by priority, then by time
        if (sortingPref === 1) {
            if (a.prio === b.prio) {
                // Convert dates to Date objects for accurate comparison
                let dateA = new Date(a.dateAssigned);
                let dateB = new Date(b.dateAssigned);
                return dateA - dateB;  // Nearest dates first
            }
            return a.prio < b.prio ? -1 : 1;  // Highest priority (lowest number) first
        }

        // Sorting by time
        if (sortingPref === 0) {
            let dateA = new Date(a.dateAssigned);
            let dateB = new Date(b.dateAssigned);
            return dateA - dateB;  // Nearest dates first
        }
    });
}

function fetchTasks() {
    fetch('../API/Tasks/getListTasks.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    alert(data.error);
                }

            } else if (data.message) {

            } else {
                // Fetch the sorting preference
                fetch('../API/Lists/getOneList.php')
                    .then(response => response.json())
                    .then(listData => {
                        if (listData.error) {
                            if (listData.error === 'User not logged in.') {
                                window.location.href = 'index.html';
                            } else {
                                alert(listData.error);
                            }
                        }
                        else if (!listData.error) {
                            // Sort the tasks based on the sorting preference
                            sortTasks(data, listData.sortingPref);

                            // Then generate the HTML for the tasks
                            generateTaskHTML(data);
                        }
                    });
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            alert('An error occurred while fetching task data. Please try again.');
        });
}



//for task update popup 
function fetchTaskData(taskID) {
    // Construct the payload to send with the fetch request.
    const payload = {
        taskID: taskID
    };

    fetch('../API/Tasks/getSingleTask.php', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                if (data.error === 'User not logged in.') {
                    window.location.href = 'index.html';
                } else {
                    alert(data.error);
                }
            } else {
                // If there's no error, populate the form fields with the returned data.
                document.getElementById('update-task-input').value = data.taskText;
                document.getElementById('update-priority-select').value = data.prio;
                document.getElementById('update-taskType-select').value = data.type;
                document.getElementById('update-date-assigned-input').value = data.dateAssigned.replace(' ', 'T');
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            alert('An error occurred while fetching task data. Please try again.');
        });
}





//task complete and delete

function handleTaskCompletion(taskID) {
    const payload = {
        taskID: taskID
    };
    fetch('../API/Tasks/completeTask.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            if (data.error === 'User not logged in.') {
                window.location.href = 'index.html';
            } else if (data.error) {
                alert(data.error);
            } else {
                const karim = document.querySelector(`.karim[data-task-id="${taskID}"]`);
                karim.classList.add('slide-left');
                setTimeout(() => {
                    location.reload();
                }, 250); // Delay for animation
            }
        });
}

function handleTaskDeletion(taskID) {
    const payload = {
        taskID: taskID
    };
    fetch('../API/Tasks/deleteTask.php', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            if (data.error === 'User not logged in.') {
                window.location.href = 'index.html';
            } else if (data.error) {
                alert(data.error);
            } else {
                const karim = document.querySelector(`.karim[data-task-id="${taskID}"]`);
                karim.classList.add('slide-right');
                setTimeout(() => {
                    location.reload();
                }, 250); // Delay for animation
            }
        });
}

//for text search
//for text search
//for text search


const searchInput = document.getElementById('search-input');
const searchIcon = document.querySelector('.bi.bi-search');

function clearHighlights() {
    document.querySelectorAll('.highlight').forEach(highlight => {
        let textNode = document.createTextNode(highlight.textContent);
        highlight.parentNode.replaceChild(textNode, highlight);
    });
}

// This function sets highlights on the given node for the given term
function setHighlights(node, term) {
    const content = node.textContent;
    const newContent = content.replace(new RegExp(term, 'gi'), match => `<span class="highlight">${match}</span>`);
    node.innerHTML = newContent;
}

// Variables to keep track of the current and all highlighted elements
let currentHighlightIndex = 0;
let highlightedElements = [];

searchInput.addEventListener('input', handleSearchInputEvent);

function handleSearchInputEvent() {
    // Clear any previous highlights
    clearHighlights();

    // Reset the current highlight index
    currentHighlightIndex = 0;

    // Get the entered text
    const term = searchInput.value;

    if (term) {
        // Search and highlight matches
        document.querySelectorAll('.karim p').forEach(p => {
            if (p.textContent.toLowerCase().includes(term.toLowerCase())) {
                setHighlights(p, term);
            }
        });

        // Populate the highlightedElements array with the new highlights
        highlightedElements = document.querySelectorAll('.highlight');
    }
}


searchIcon.addEventListener('click', handleSearchIconClick);

function handleSearchIconClick() {
    if (highlightedElements.length) {
        // Remove active-highlight class from the previous active highlight
        document.querySelectorAll('.active-highlight').forEach(el => {
            el.classList.remove('active-highlight');
        });

        // Scroll to the current highlight
        highlightedElements[currentHighlightIndex].scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });

        // Add the active-highlight class to the current highlight
        highlightedElements[currentHighlightIndex].classList.add('active-highlight');

        // Move to the next highlight or reset to the first one if we're at the end
        currentHighlightIndex = (currentHighlightIndex + 1) % highlightedElements.length;
    }
}

//for encryption
//for encryption
//for encryption


function encrypt(data) {
    let cipher = someEncryptionFunction('base64','your_secure_encryption_key');
    let encrypted = cipher.update(data, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

function decrypt(data) {
    let decipher = someDecryptionFunction('base64', 'your_secure_encryption_key');
    let decrypted = decipher.update(data, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

function someEncryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            return btoa(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}

function someDecryptionFunction(algorithm, key) {
    return {
        update: function (data, inputEncoding, outputEncoding) {
            if (!data) {
                console.error("The data to decrypt is not available");
                return "";
            }
            return atob(data); // Not secure
        },
        final: function () {
            return "";
        }
    };
}

