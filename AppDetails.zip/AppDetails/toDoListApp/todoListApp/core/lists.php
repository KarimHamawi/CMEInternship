<?php
class Lists
{
    private $conn;

    //constructor
    public function __construct($db)
    {
        $this->conn = $db;
    }

    //helpers
    public function listExistsForUser($listID, $userID)
    {
        $query = 'SELECT listName FROM list WHERE listID = ? AND userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $listID, $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            return null; // List not found
        }
        $row = $result->fetch_assoc();
        return $row['listName'];
    }


    private function deleteListTasks($listID)
    {
        $query = 'DELETE FROM task WHERE listID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $listID);
        $stmt->execute();


        $query = 'DELETE FROM task WHERE originalListID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $listID);
        $stmt->execute();
    }

    private function getNonDefaultLists($userID)
    {
        $query = 'SELECT listID FROM list WHERE userID = ? AND listName NOT IN (?, ?)';
        $stmt = $this->conn->prepare($query);
        $defaultLists = ['CompletedTasksList', 'recycleBin'];
        $stmt->bind_param('iss', $userID, $defaultLists[0], $defaultLists[1]);
        $stmt->execute();
        $result = $stmt->get_result();

        $lists = array();
        while ($row = $result->fetch_assoc()) {
            $lists[] = $row['listID'];
        }

        return $lists;
    }


    private function getPreferredList($userID)
    {
        $query = 'SELECT preferredList FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['preferredList'];
    }



    //non helpers
    //non helpers
    //non helpers
    public function createList($userID, $listName, $sortingPref = null)
    {
        // Check if userID is provided
        if (empty($userID)) {
            return ['error' => 'User ID is required.'];
        }

        // Check if listName is provided
        if (empty($listName)) {
            return ['error' => 'List name is required.'];
        }

        // Check if the list name is one of the forbidden names
        if ($listName === 'CompletedTasksList' || $listName === 'recycleBin') {
            return ['error' => 'Invalid value for listName. It cannot be "CompletedTasksList" or "recycleBin".'];
        }

        // Validate sortingPref (should be null, 0, or 1)
        if ($sortingPref !== null && !is_int($sortingPref) && ($sortingPref !== 0 && $sortingPref !== 1)) {
            return ['error' => 'Invalid value for sortingPref. It should be null, 0, or 1.'];
        }

        // Insert the new list into the database
        if ($sortingPref !== null) {
            $query = 'INSERT INTO list (userID, listName, sortingPref) VALUES (?, ?, ?)';
        } else {
            $query = 'INSERT INTO list (userID, listName) VALUES (?, ?)';
        }
        $stmt = $this->conn->prepare($query);

        if ($sortingPref !== null) {
            $stmt->bind_param('iss', $userID, $listName, $sortingPref);
        } else {
            $stmt->bind_param('is', $userID, $listName);
        }

        if ($stmt->execute()) {
            $listID = $stmt->insert_id;
            $_SESSION['list_id'] = $listID;

            // List created successfully
            return ['success' => 'List created successfully.'];
        } else {
            // Failed to create list
            return ['error' => 'Failed to create list.'];
        }
    }


    public function deleteList($userID, $listID)
    {
        // Check if listID is provided
        if (empty($listID)) {
            return ['error' => 'ListID is required.'];
        }

        // Fetch the list name associated with the given listID
        $listName = $this->listExistsForUser($listID, $userID);

        // If the listName is null, it means that the listID does not belong to the user
        if ($listName === null) {
            return ['error' => 'The specified list does not belong to this user.'];
        }

        // Check if the listName is one of the forbidden names
        if ($listName === 'CompletedTasksList' || $listName === 'recycleBin') {
            return ['error' => 'Invalid value for list. It cannot refer to the lists "CompletedTasksList" or "recycleBin".'];
        }

        // Check if the user has more than one list (excluding "recycleBin" and "CompletedTasksList")
        $nonDefaultLists = $this->getNonDefaultLists($userID);

        // If the user has only one list (the one being deleted), return an error
        if (count($nonDefaultLists) <= 1) {
            return ['error' => 'Cannot delete the only list of the user (excluding "recycleBin" and "CompletedTasksList").'];
        }

        // Check if the list being deleted is the user's preferredList
        $preferredListID = $this->getPreferredList($userID);

        if ($listID == $preferredListID) {
            // Remove the list the user wants to delete from the non-default lists
            $nonDefaultLists = array_diff($nonDefaultLists, [$listID]);

            // Choose a random list from the remaining non-default lists to be the new preferredList
            $preferredListID = $nonDefaultLists[array_rand($nonDefaultLists)];

            // Update the user's preferredList in the database
            $query = 'UPDATE user SET preferredList = ? WHERE userID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $preferredListID, $userID);
            $stmt->execute();

            // Set the preferredList in the current session
            $_SESSION['list_id'] = $preferredListID;
        } else {
            // Set the preferredList in the current session (no need to update in the database)
            $_SESSION['list_id'] = $preferredListID;
        }

        // Begin a database transaction
        $this->conn->begin_transaction();

        try {
            // Delete all tasks associated with the list
            $this->deleteListTasks($listID);

            // Delete the list from the database
            $query = 'DELETE FROM list WHERE listID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('i', $listID);

            if ($stmt->execute()) {
                // Commit the transaction if both operations are successful
                $this->conn->commit();
                return ['success' => 'List deleted successfully.'];
            } else {
                // Rollback the transaction if the list deletion fails
                $this->conn->rollback();
                return ['error' => 'Failed to delete list.'];
            }
        } catch (Exception $e) {
            // Rollback the transaction if an exception is thrown during the transaction
            $this->conn->rollback();
            return ['error' => $e->getMessage()];
        }
    }


    public function getAllUserLists($userID)
    {
        // Check if userID is provided
        if (empty($userID)) {
            return ['error' => 'User ID is required.'];
        }

        // Fetch all lists for the user from the database excluding the userID column
        $query = 'SELECT listID, listName, sortingPref FROM list WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        $lists = array();
        while ($row = $result->fetch_assoc()) {
            $lists[] = $row;
        }

        return $lists;
    }

    public function getOneList($listID)
    {


        // Fetch all lists for the user from the database excluding the userID column
        $query = 'SELECT listID, listName, sortingPref FROM list WHERE listID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $listID);
        $stmt->execute();
        $result = $stmt->get_result();

        $data = $result->fetch_assoc();
        return $data;
    }

    public function updateList($userID, $listID, $listName = null, $sortingPref = null)
    {
        // Check if listID is provided
        if (empty($listID)) {
            return ['error' => 'List ID is required.'];
        }

        // Fetch the list name associated with the given listID
        $listNameDB = $this->listExistsForUser($listID, $userID);

        // If the listName is null, it means that the listID does not belong to the user
        if ($listNameDB === null) {
            return ['error' => 'The specified list does not belong to this user.'];
        }

        // Check if the listName is one of the forbidden names
        if ($listNameDB === 'CompletedTasksList' || $listNameDB === 'recycleBin') {
            return ['error' => 'Invalid value for list. It cannot be "CompletedTasksList" or "recycleBin".'];
        }

        // Initialize an empty array to store the fields and values to be updated
        $updateFields = array();

        if ($listName !== null) {
            // Check if the listName is one of the forbidden names
            if ($listName === 'CompletedTasksList' || $listName === 'recycleBin') {
                return ['error' => 'Invalid value for listName. It cannot be "CompletedTasksList" or "recycleBin".'];
            }
            $updateFields[] = 'listName = "' . $this->conn->real_escape_string($listName) . '"';
        }

        if ($sortingPref !== null) {
            // Validate sortingPref (should be 0 or 1)
            if (!is_int($sortingPref) || ($sortingPref !== 0 && $sortingPref !== 1)) {
                return ['error' => 'Invalid value for sortingPref. It should be 0 or 1.'];
            }
            $updateFields[] = 'sortingPref = ' . $sortingPref;
        }

        // If no valid fields to update, return an error
        if (count($updateFields) === 0) {
            return ['error' => 'No valid fields to update.'];
        }

        // Construct the update query dynamically
        $query = 'UPDATE list SET ' . implode(', ', $updateFields) . ' WHERE listID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $listID);

        if ($stmt->execute()) {
            // List updated successfully
            return ['success' => 'List updated successfully.'];
        } else {
            // Failed to update list
            return ['error' => 'Failed to update list.'];
        }
    }
}
