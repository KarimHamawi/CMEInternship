<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class UserwithSettings
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }


    //helpers
    private function generatePassword()
    {
        // Define the characters to use for generating the password
        $uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
        $digits = '0123456789';
        $specialChars = '!@#$%^&*()-_=+';

        // Combine all character sets to create the full character pool for the password
        $allChars = $uppercaseLetters . $lowercaseLetters . $digits . $specialChars;

        // Initialize an empty string to store the generated password
        $password = '';

        // Generate a password with at least 8 characters
        while (strlen($password) < 8) {
            // Randomly select a character from the pool
            $randomChar = $allChars[random_int(0, strlen($allChars) - 1)];

            // Append the character to the password
            $password .= $randomChar;
        }

        // Ensure the password contains at least one uppercase letter, one lowercase letter, and one digit
        while (!preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/\d/', $password)) {
            // Replace one random character with a new random character from the pool
            $randomIndex = random_int(0, strlen($password) - 1);
            $randomChar = $allChars[random_int(0, strlen($allChars) - 1)];
            $password = substr_replace($password, $randomChar, $randomIndex, 1);
        }

        return $password;
    }


    private function userExists($userID)
    {
        $query = 'SELECT COUNT(*) as count FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'] > 0;
    }

    //createdefaults used for signup
    private function createDefaultLists($userID)
    {
        // Create the default lists for the user (recycleBin and completedTasks)
        // Assuming 'list' is the table for lists

        // Create Recycle Bin list
        $query = 'INSERT INTO list (listName, userID) VALUES ("recycleBin", ?)';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();

        // Create Completed Tasks list
        $query = 'INSERT INTO list (listName, userID) VALUES ("CompletedTasksList", ?)';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();

        // Create list1
        $query = 'INSERT INTO list (listName, userID) VALUES ("list1", ?)';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();

        // Get the listID of list1 that was just created
        $list1ID = $stmt->insert_id;

        // Return the listID of list1
        return $list1ID;
    }

    private function updatePreferredList($userID, $preferredListID)
    {
        $query = 'UPDATE user SET preferredList = ? WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $preferredListID, $userID);
        $stmt->execute();
    }


    private function emailExists($email)
    {
        $query = 'SELECT COUNT(*) as count FROM user WHERE email = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'] > 0; // Return true if email exists, false otherwise
    }


    private function listExistsForUser($listID, $userID)
    {
        $query = 'SELECT listName FROM list WHERE listID = ? AND userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $listID, $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            return null; // List not found
        }
        $row = $result->fetch_assoc();
        return $row['listName'];
    }

    public function emailHelper($userID)
    {

        // Get the user's emailDecision and reminderTiming from the database
        $query = 'SELECT emailDecision, reminderTiming FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the user exists and has emailDecision and reminderTiming set
        if ($result->num_rows === 0) {
            return ['error' => 'User not found or emailDecision/reminderTiming not set.'];
        }


        $row = $result->fetch_assoc();
        $emailDecision = $row['emailDecision'];
        $reminderTiming = $row['reminderTiming'];

        // If emailDecision is 0, no emails are sent, return immediately
        if ($emailDecision === 0) {
            return ['message' => 'Emails are disabled for this user.'];
        }

        // Get the current timestamp
        $currentTimestamp = time();

        // Fetch all tasks from the database that are not in "recycleBin" or "CompletedTasksList"
        $query = 'SELECT * FROM task WHERE listID NOT IN (SELECT listID FROM list WHERE listName IN ("recycleBin", "CompletedTasksList"))';
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        // Initialize an array to store the taskIDs for which reminders should be sent
        $tasksToSendReminder = array();
        // Loop through the tasks and check if reminders should be sent
        while ($row = $result->fetch_assoc()) {
            $taskID = $row['taskID'];
            $dateAssignedTimestamp = strtotime($row['dateAssigned']);
            $reminderTime = $dateAssignedTimestamp - (60 * $reminderTiming);

            // Check if the task's date assigned is within the reminder timing range (within 0 to 3 minutes from the time threshold)
            if ($currentTimestamp >= ($reminderTime - (60)) && $currentTimestamp <= $reminderTime) {
                $tasksToSendReminder[] = $taskID;
            }
        }
        // Initialize an array to store the tasks for which reminders were sent
        $remindedTasks = array();

        // Call the sendEmail function for each task that requires a reminder
        foreach ($tasksToSendReminder as $taskID) {
            $result = $this->sendEmail($userID, $taskID);

            if (isset($result['success'])) {
                $remindedTasks[] = $result['success'];
            } elseif (isset($result['error'])) {
                $remindedTasks[] = $result['error'];
            }
        }

        // Check if any reminders were sent
        if (empty($remindedTasks)) {
            return ['message' => 'No reminders were sent for any tasks.'];
        } elseif (count($remindedTasks) > 0) {
            return array('success' => 'Emails sent successfully.', 'remindedTasks' => $remindedTasks);
        }
    }


    private function sendEmail($userID, $taskID)
    {

        require '../vendor/autoload.php';

        // Fetch the user's email address from the database
        $query = 'SELECT email FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the user exists and has an email address set
        if ($result->num_rows === 0) {
            return ['error' => 'User not found or email not set.'];
        }

        $row = $result->fetch_assoc();
        $email = $row['email'];

        // Fetch the task details from the database
        $query = 'SELECT taskText, listID, dateAssigned FROM task WHERE taskID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $taskID);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the task exists
        if ($result->num_rows === 0) {
            return ['error' => 'Task not found.'];
        }

        $row = $result->fetch_assoc();
        $taskText = $row['taskText'];
        $dateAssigned = $row['dateAssigned'];
        $listID = $row['listID'];

        // Create a new PHPMailer instance
        $mail = new PHPMailer(true);

        // Set the mailer to use SMTP (Optional - only if you want to use SMTP)
        $mail->isSMTP();
        $mail->Host = 'localhost';
        $mail->SMTPAuth = false;
        $mail->Username = '';
        $mail->Password = '';
        $mail->SMTPSecure = '';
        $mail->Port = 1025;

        // Set the sender and recipient email addresses
        $mail->setFrom('taskreminder@example.com', 'Task Reminder');
        $mail->addAddress($email);

        // Compose the email message
        $mail->Subject = 'Task Reminder';
        $mail->Body = "Dear User,\n\nThis is a reminder for the task '$taskText' assigned on $dateAssigned.\n\nBest regards,\nThe Task Reminder Team";

        // Send the email
        if ($mail->send()) {
            return ['success' => "Reminder email sent for task '$taskText' assigned on date $dateAssigned on list $listID successfully."];
        } else {
            return ['error' => "Failed to send reminder email for task '$taskText' assigned on date $dateAssigned. Error: {$mail->ErrorInfo}"];
        }
    }


    //controller functions
    public function getPreferredList($userID)
    {
        $query = 'SELECT preferredList FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return null; // User not found or preferredList is not set
        }

        $row = $result->fetch_assoc();
        return $row['preferredList'];
    }


    //this should be called periodically by the server
    public function deleteAllTemporaryUsers()
    {
        // SQL to select all temporary users (isTemporary=1)
        $query = "SELECT userID FROM user WHERE isTemporary = 1";

        // Prepare and execute the statement to get temporary users
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        // Start a transaction to ensure data consistency
        $this->conn->begin_transaction();

        try {
            while ($row = $result->fetch_assoc()) {
                $userID = $row['userID'];

                // Delete all tasks associated with the user
                $query = 'DELETE FROM task WHERE listID IN (SELECT listID FROM list WHERE userID = ?)';
                $stmt = $this->conn->prepare($query);
                $stmt->bind_param('i', $userID);
                $stmt->execute();

                // Delete all lists associated with the user
                $query = 'DELETE FROM list WHERE userID = ?';
                $stmt = $this->conn->prepare($query);
                $stmt->bind_param('i', $userID);
                $stmt->execute();

                // Delete the user account
                $query = 'DELETE FROM user WHERE userID = ?';
                $stmt = $this->conn->prepare($query);
                $stmt->bind_param('i', $userID);
                $stmt->execute();
            }

            // Commit the transaction
            $this->conn->commit();

            return ['success' => 'All temporary accounts deleted successfully.'];
        } catch (Exception $e) {
            // If any error occurs, rollback the transaction
            $this->conn->rollback();
            return ['error' => 'Failed to delete all temporary accounts.'];
        }
    }


    public function confirm($pass, $userID)
    {
        $query = 'SELECT * FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return ['error' => 'User not found.'];
        }

        $user = $result->fetch_assoc();
        // Verify the password using password_verify()
        if (password_verify($pass, $user['password'])) {
            // Password is correct, return user data

            return ['success' => 'Password verified.'];
        } else {
            // Password is incorrect
            return ['error' => 'Incorrect old password.'];
        }
    }

    public function getSettings($userID)
    {
        if (!$this->userExists($userID)) {
            return ['error' => 'User not found.'];
        }

        // Specify the columns to select from the user table (excluding 'creationDate' and 'userID')
        $query = 'SELECT fullName, email, points, emailDecision, reminderTiming, preferredList, recycleBinDecision, tutorialCompletion, isTemporary FROM user WHERE userID = ?';

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }


    public function updateSettings(
        $userID,
        $fullName = null,
        $password = null,
        $emailDecision = null,
        $reminderTiming = null,
        $preferredList = null,
        $recycleBinDecision = null
    ) {
        if (!$this->userExists($userID)) {
            return ['error' => 'User not found.'];
        }

        // Initialize an empty array to store the fields and values to be updated
        $updateFields = array();

        // Check and validate full name format (First name and Last name with the first letter of each capitalized)
        if ($fullName !== null) {
            if (!preg_match('/^[A-Z][a-z]+ [A-Z][a-z]+$/', $fullName)) {
                return ['error' => 'Full name should be in the format "First Last" with the first letter of each name capitalized.'];
            }
            $updateFields[] = 'fullName = "' . $this->conn->real_escape_string($fullName) . '"';
        }

        // Check and validate password format (at least 8 characters long and contains at least one uppercase letter, one lowercase letter, and one digit)
        if ($password !== null) {
            if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
                return ['error' => 'Password should be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one digit.'];
            }
            // Hash the password using password_hash function
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $updateFields[] = 'password = "' . $this->conn->real_escape_string($hashedPassword) . '"';
        }

        if ($emailDecision !== null) {
            // Validate emailDecision (should be 0 or 1)
            if ($emailDecision !== 0 && $emailDecision !== 1) {
                return ['error' => 'Invalid value for emailDecision. It should be 0 or 1.'];
            }
            $updateFields[] = 'emailDecision = ' . intval($emailDecision);
        }
        if ($reminderTiming !== null) {
            // Validate reminderTiming (should be a positive integer)
            if (!is_int($reminderTiming) || $reminderTiming <= 0) {
                return ['error' => 'Invalid value for reminderTiming. It should be a positive integer.'];
            }
            $updateFields[] = 'reminderTiming = ' . intval($reminderTiming);
        }
        // Check and validate the preferredList (if provided)
        if ($preferredList !== null) {
            // Fetch the list name associated with the given listID
            $listName = $this->listExistsForUser($preferredList, $userID);

            // Check if the preferredList is one of the forbidden names
            if ($listName === 'CompletedTasksList' || $listName === 'recycleBin') {
                return ['error' => 'Invalid value for preferredList. It cannot be "CompletedTasksList" or "recycleBin".'];
            }

            // Validate preferredList (should be one of the lists that belong to this user)
            if (!$listName) {
                return ['error' => 'Invalid value for preferredList. It should be one of the lists that belong to this user.'];
            }
            $updateFields[] = 'preferredList = ' . intval($preferredList);
        }

        if ($recycleBinDecision !== null) {
            // Validate recycleBinDecision (should be 0 or 1)
            if ($recycleBinDecision !== 0 && $recycleBinDecision !== 1 && $recycleBinDecision !== 2 && $recycleBinDecision !== 3 && $recycleBinDecision !== 4) {
                return ['error' => 'Invalid value for recycleBinDecision. It should be 0, 1, 2, 3, or 4.'];
            }
            $updateFields[] = 'recycleBinDecision = ' . intval($recycleBinDecision);
        }

        // If no valid fields to update, return an error
        if (count($updateFields) === 0) {
            return ['error' => 'No valid fields to update.'];
        }

        // Construct the update query dynamically
        $query = 'UPDATE user SET ' . implode(', ', $updateFields) . ' WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);

        if ($stmt->execute()) {
            return ['success' => 'Settings updated successfully.'];
        } else {
            return ['error' => 'Failed to update settings.'];
        }
    }


    public function forgotPassword($email)
    {
        require '../../vendor/autoload.php';
        // Check if the provided email exists in the database
        $query = 'SELECT * FROM user WHERE email = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return ['error' => 'User with this email does not exist.'];
        }

        // Generate a unique token for password reset
        $resetToken = $this->generatePassword();


        // Store the email, reset token, and expiration time in the database
        $expires_at = new DateTime('now');
        $expires_at->modify('+1 hour'); // Token valid for 1 hour
        $query = 'INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)';
        $stmt = $this->conn->prepare($query);
        $formatted_expires_at = $expires_at->format('Y-m-d H:i:s');
        $stmt->bind_param('sss', $email, $resetToken, $formatted_expires_at);
        

        if (!$stmt->execute()) {
            return ['error' => 'Failed to store reset token in the database.'];
        }

        // Encrypt email and token using OpenSSL
        $cipher = "aes-128-cbc";
        $key = "your_secure_encryption_key"; // Replace with your own secure key
        $ivlen = openssl_cipher_iv_length($cipher);
        $iv = openssl_random_pseudo_bytes($ivlen);

        $encryptedEmail = openssl_encrypt($email, $cipher, $key, 0, $iv);
        $encryptedToken = openssl_encrypt($resetToken, $cipher, $key, 0, $iv);

        // Encode the encrypted data and IV
        $urlSafeData = urlencode(base64_encode($encryptedEmail)) . ':' . urlencode(base64_encode($encryptedToken)) . ':' . urlencode(base64_encode($iv));

        // Send the email with the reset password link
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'localhost';
        $mail->SMTPAuth = false;
        $mail->Username = '';
        $mail->Password = '';
        $mail->SMTPSecure = '';
        $mail->Port = 1025;
        $mail->isHTML(true);

        $mail->setFrom('taskreminder@example.com', 'Task Reminder');
        $mail->addAddress($email);

        $encodedToken = urlencode($resetToken);
        $resetLink = "http://localhost/toDoListApp/todoListApp/API/UserWithSettings/login2.php?data={$urlSafeData}";

        $mail->Subject = 'Forgot Password - Reset Your Password';
        $mail->Body = "Hello, you have requested to reset your password. Your new password will be $resetToken once you click the link.<br><br>" .
            "Please click the link below to reset your password:<br>" .
            "<a href='{$resetLink}'>Reset Password</a><br><br>" .
            "Best regards,<br>The Task Reminder Team";

        try {
            $mail->send();
            return ['success' => 'Password reset email sent. Please check your inbox for the reset link.'];
        } catch (Exception $e) {
            return ['error' => 'Failed to send the password reset email.'];
        }
    }

    public function login($email, $password)
    {
        // Check if the user exists in the database based on the email
        $query = 'SELECT * FROM user WHERE email = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return ['error' => 'User not found.'];
        }

        $user = $result->fetch_assoc();

        // Verify the password using password_verify()
        if (password_verify($password, $user['password'])) {
            // Password is correct, return user data
            unset($user['password']); // Remove hashed password from the response
            return $user;
        } else {
            // Password is incorrect
            return ['error' => 'Incorrect password.'];
        }
    }


    public function signup($fullName, $email, $password, $isTemporary = 0)
    {
        // Check if the email already exists
        if ($this->emailExists($email)) {
            return ['error' => 'Email already exists.'];
        }

        // Validate full name format (First name and Last name with the first letter of each capitalized)
        if (!preg_match('/^[A-Z][a-z]+ [A-Z][a-z]+$/', $fullName)) {
            return ['error' => 'Full name should be in the format "First Last" with the first letter of each name capitalized.'];
        }

        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['error' => 'Invalid email format.'];
        }

        // Validate password (at least 8 characters long and contains at least one uppercase letter, one lowercase letter, and one digit)
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
            return ['error' => 'Password should be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one digit.'];
        }

        // Hash the password securely
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Create the SQL query to insert the new user
        $query = 'INSERT INTO user (fullName, email, password, isTemporary) VALUES (?, ?, ?, ?)';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('sssi', $fullName, $email, $hashedPassword, $isTemporary);

        // Execute the query
        if ($stmt->execute()) {
            // Get the userID of the newly created user
            $userID = $stmt->insert_id;

            // Create the default lists for the user (recycleBin, completedTasks, and list1)
            $preferredListID = $this->createDefaultLists($userID);

            // Set the user's "preferredList" to the ID of "list1"
            $this->updatePreferredList($userID, $preferredListID);

            // Set the user ID in the session variable for automatic login
            $_SESSION['user_id'] = $userID;

            // Store the "list1" ID in the session variable
            $_SESSION['list_id'] = $preferredListID;


            return ['success' => 'User created successfully and you have successfully signed in.', 'tutorialStatus' => 'incomplete'];

        } else {
            return ['error' => 'Failed to create user.'];
        }
    }


    public function completeTutorial($userID)
    {
        // Fetch current status of tutorialCompletion for the user
        $query = 'SELECT tutorialCompletion FROM user WHERE userID = ? LIMIT 1';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $currentStatus = $row['tutorialCompletion'];

        // Toggle the tutorialCompletion value
        $newStatus = ($currentStatus == 1) ? 0 : 1;

        // Update the status
        $query = 'UPDATE user SET tutorialCompletion = ? WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $newStatus, $userID);

        if ($stmt->execute()) {
            return $newStatus;
        } else {
            return false;
        }
    }



    public function deleteAccount($userID)
    {
        // Check if the user exists in the database
        if (!$this->userExists($userID)) {
            return ['error' => 'User not found.'];
        }

        // Start a transaction to ensure data consistency
        $this->conn->begin_transaction();

        try {
            // Delete all tasks associated with the user
            $query = 'DELETE FROM task WHERE listID IN (SELECT listID FROM list WHERE userID = ?)';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('i', $userID);
            $stmt->execute();

            // Delete all lists associated with the user
            $query = 'DELETE FROM list WHERE userID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('i', $userID);
            $stmt->execute();

            // Delete the user account
            $query = 'DELETE FROM user WHERE userID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('i', $userID);
            $stmt->execute();

            // Commit the transaction
            $this->conn->commit();

            // // Unset the user_id session variable for logout
            unset($_SESSION['user_id']);

            // Return success message
            return ['success' => 'Account deleted successfully.'];
        } catch (Exception $e) {
            // If any error occurs, rollback the transaction
            $this->conn->rollback();
            return ['error' => 'Failed to delete account.'];
        }
    }
}