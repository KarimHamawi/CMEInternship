<?php
class Articles
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    private function userExists($userID)
    {
        $query = 'SELECT COUNT(*) as count FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'] > 0;
    }

    public function getUserPoints($userID)
    {
        if (!$this->userExists($userID)) {
            return ['error' => 'User not found.'];
        }

        $query = 'SELECT points FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return ($row && isset($row['points'])) ? (int) $row['points'] : 0;
    }


}
