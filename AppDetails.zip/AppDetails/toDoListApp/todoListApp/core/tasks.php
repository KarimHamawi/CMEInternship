<?php
class Tasks
{
    private $conn;
    public function __construct($db)
    {
        $this->conn = $db;
    }

    // helper functions
    public function listExistsForUser($listID, $userID)
    {
        $query = 'SELECT listName FROM list WHERE listID = ? AND userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $listID, $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            return null; // List not found
        }
        $row = $result->fetch_assoc();
        return $row['listName'];
    }
    public function taskExistsForList($taskID, $listID)
    {
        $query = 'SELECT COUNT(*) as count FROM task WHERE taskID = ? AND listID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $taskID, $listID);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'] > 0;
    }

    private function moveTaskToOriginalList($taskID, $listID, $nextDateAssigned)
    {
        $query = 'UPDATE task SET listID = ?, dateAssigned = ? WHERE taskID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('isi', $listID, $nextDateAssigned, $taskID);
        $stmt->execute();
        $stmt->close();
    }

    public function getCompletedTasksListID($userID)
    {
        $query = 'SELECT listID FROM list WHERE userID = ? AND listName = "CompletedTasksList"';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return null; // CompletedTasksList not found for the user
        }

        $list = $result->fetch_assoc();
        return $list['listID'];
    }


    private function getOriginalListIDForTask($taskID)
    {
        $originalListID = 0;
        $query = 'SELECT originalListID FROM task WHERE taskID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $taskID);
        $stmt->execute();
        $stmt->bind_result($originalListID);

        $result = $stmt->fetch();
        $stmt->close();

        if ($result) {
            return $originalListID;
        } else {
            return null;
        }
    }

    private function getRecycleBinListID($userID)
    {
        $query = 'SELECT listID FROM list WHERE userID = ? AND listName = "recycleBin"';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return null;
        }

        $list = $result->fetch_assoc();
        return $list['listID'];
    }


    private function getRecycleBinDecision($userID)
    {
        $recycleBinDecision = null;
        $query = 'SELECT recycleBinDecision FROM user WHERE userID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        $stmt->bind_result($recycleBinDecision);
        $stmt->fetch();
        $stmt->close();

        return $recycleBinDecision;
    }


    public function isTaskInSpecialList($taskID)
    {
        // Get the task details
        $task = $this->getSingleTask($taskID);

        // If task not found, return false
        if (isset($task['error'])) {
            return false;
        }

        // Get the listName of the task
        $listID = $task['listID'];
        $listName = $this->getListNameByID($listID);

        // Check if the listName belongs to the recycleBin or CompletedTasksList
        if ($listName === 'recycleBin' || $listName === 'CompletedTasksList') {
            return true;
        }

        return false;
    }

    public function getListNameByID($listID)
    {
        $query = 'SELECT listName FROM list WHERE listID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $listID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return null;
        }

        $list = $result->fetch_assoc();
        return $list['listName'];
    }
    
    public function getLastCreatedTask($listID)
{
    $query = 'SELECT * FROM task WHERE listID = ? ORDER BY taskID DESC LIMIT 1';
    $stmt = $this->conn->prepare($query);
    $stmt->bind_param('i', $listID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        return null;
    }

    $task = $result->fetch_assoc();
    return $task;
}

    // controller functions
     // controller functions
      // controller functions


    // Function to create a single task
    public function createSingleTask($userID, $listID, $taskText, $dateAssigned, $type = null, $prio = null)
    {

        // Check if taskText is provided
        if (empty($taskText)) {
            return ['error' => 'Task text is required.'];
        }

        // Check if userID is provided
        if (empty($userID)) {
            return ['error' => 'User ID is required.'];
        }

        // Check if listID is provided
        if (empty($listID)) {
            return ['error' => 'List ID is required.'];
        }

        if (empty($dateAssigned)) {
            return ['error' => 'Date assigned is required.'];
        }

        // Fetch the list name associated with the given listID
        $listName = $this->listExistsForUser($listID, $userID);

        // If the listName is null, it means that the listID does not belong to the user
        if ($listName === null) {
            return ['error' => 'The specified list does not belong to this user.'];
        }
        // Check if the listName is one of the forbidden names
        if ($listName === 'CompletedTasksList' || $listName === 'recycleBin') {
            return ['error' => 'Invalid value for listID. It cannot be "CompletedTasksList" or "recycleBin".'];
        }

        // Validate dateAssigned (should be after the current timestamp)
        $currentTimestamp = time();
        $dateAssignedTimestamp = strtotime($dateAssigned);
        if ($dateAssignedTimestamp === false || $dateAssignedTimestamp < $currentTimestamp) {
            return ['error' => 'Invalid value for dateAssigned. It should be a date after the current time.'];
        }

        // Check and validate the type (if provided)
        if ($type !== null) {
            // Validate type (should be within the allowed range)
            if (!in_array($type, [0, 1, 2, 3, 4, 5])) {
                return ['error' => 'Invalid value for type. It should be one of the allowed values.'];
            }
        }

        // Check and validate the prio (if provided)
        if ($prio !== null) {
            // Validate prio (should be within the allowed range)
            if ($prio < 1 || $prio > 5) {
                return ['error' => 'Invalid value for prio. It should be between 1 and 5.'];
            }
        }

        // If type and prio are not provided, set them to their default values
        $type = $type ?? 0;
        $prio = $prio ?? 1;

        // Set originalListID to the same value as listID
        $originalListID = $listID;

        $query = 'INSERT INTO task (listID, originalListID, taskText, dateAssigned, type, prio) VALUES (?, ?, ?, ?, ?, ?)';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('iissii', $listID, $originalListID, $taskText, $dateAssigned, $type, $prio);

        if ($stmt->execute()) {
            // Task created successfully
            return ['success' => 'Task created successfully.'];
        } else {
            // Failed to create task
            return ['error' => 'Failed to create task.'];
        }
    }


    public function completeTask($userID, $listID, $taskID)
    {
        $response = array();

        // Check if the taskID belongs to this list
        if (!$this->taskExistsForList($taskID, $listID)) {
            $response['error'] = 'The specified task does not belong to this list.';
            return $response;
        }

        // Check if the task is in the recycleBin or CompletedTasksList
        $listName = $this->getListNameByID($listID);
        if ($listName === 'recycleBin' || $listName === 'CompletedTasksList') {
            // Task was in recycleBin or CompletedTasksList, move it to the original list
            $originalListID = $this->getOriginalListIDForTask($taskID);
            if (!$originalListID) {
                $response['error'] = 'Original list ID not found.';
                return $response;
            }

            // Check if the original list belongs to the user
            if (!$this->listExistsForUser($originalListID, $userID)) {
                $response['error'] = 'The original list does not belong to this user.';
                return $response;
            }

            // Update the listID of the task to the original list
            $query = 'UPDATE task SET listID = ? WHERE taskID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $originalListID, $taskID);

            if ($stmt->execute()) {

                // If the task is completed in the CompletedTasksList, subtract points from the user
                if ($listName === 'CompletedTasksList') {
                    $query = 'UPDATE user SET points = points - 1 WHERE userID = ?';
                    $stmt = $this->conn->prepare($query);
                    $stmt->bind_param('i', $userID);

                    if (!$stmt->execute()) {
                        return $response['error'] = 'Failed to update points.';
                    }
                }
                $response['success'] = 'Task completed and moved back to the original list, and points updated as well.';
            } else {
                $response['error'] = 'Failed to move task to the original list.';
            }
        } else {
            // Task was in a regular list, move it to CompletedTasksList and update points
            $completedTasksListID = $this->getCompletedTasksListID($userID); // Get the CompletedTasksList listID

            if ($completedTasksListID === null) {
                $response['error'] = 'CompletedTasksList not found.';
                return $response;
            }

            // Update the listID of the task to CompletedTasksList
            $query = 'UPDATE task SET listID = ? WHERE taskID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $completedTasksListID, $taskID);

            if (!$stmt->execute()) {
                $response['error'] = 'Failed to move task to CompletedTasksList.';
                return $response;
            }

            // Update points in the user table
            $query = 'UPDATE user SET points = points + 1 WHERE userID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('i', $userID);

            if ($stmt->execute()) {
                $response['success'] = 'Task completed and points updated.';
            } else {
                $response['error'] = 'Failed to update points.';
            }
        }

        return $response;
    }


    public function deleteExpiredTask($userID)
    {
        // Get the user's recycleBinDecision value
        $recycleBinDecision = $this->getRecycleBinDecision($userID);

        // Check if the recycleBinDecision is a valid value (0, 1, 2, 3, 4)
        if (!is_int($recycleBinDecision) || !in_array($recycleBinDecision, [0, 1, 2, 3, 4])) {
            return array('error' => 'Invalid value for recycleBinDecision.');
        }

        // Get the current date and time
        $currentTimestamp = time();

        // Calculate the time threshold based on recycleBinDecision
        $timeThresholds = [30 * 24 * 3600, 15 * 24 * 3600, 7 * 24 * 3600, 6 * 30 * 24 * 3600, 12 * 30 * 24 * 3600];
        $timeThreshold = $timeThresholds[$recycleBinDecision];

        // Fetch all tasks from the recycle bin for the user
        $recycleBinListID = $this->getRecycleBinListID($userID);
        if ($recycleBinListID === null) {
            return array('error' => 'Recycle bin not found.');
        }

        $recycleBinTasks = $this->getListTasks($recycleBinListID);

        // Initialize an array to store the deleted tasks
        $deletedTasks = array();

        // Loop through the tasks in the recycle bin
        foreach ($recycleBinTasks as $task) {
            $taskID = $task['taskID'];
            $dateAssignedTimestamp = strtotime($task['dateAssigned']);

            // Check if the task has been in the recycle bin for more than the specified time threshold
            if (($currentTimestamp - $dateAssignedTimestamp) >= $timeThreshold) {
                // Delete the task permanently from the database
                if ($this->deleteTask($userID, $recycleBinListID, $taskID)) {
                    $deletedTasks[] = array(
                        'taskID' => $taskID,
                        'listID' => $recycleBinListID,
                        'type' => $task['type'],
                        'originalListID' => $task['originalListID'],
                        'dateAssigned' => $task['dateAssigned']
                    );
                }
            }
        }

        // Check if there are any deleted tasks
        if (count($deletedTasks) > 0) {
            return array('success' => 'Expired tasks in the recycle bin deleted successfully.', 'deletedTasks' => $deletedTasks);
        } else {
            return array('message' => 'No expired tasks found in the recycle bin.');
        }
    }




    public function updateRepeatingTasks($userID)
    {
        // Get the current date and time
        $currentTimestamp = time();

        // Fetch all completed tasks for the user
        $completedTasks = $this->getListTasks($this->getCompletedTasksListID($userID));

        // Initialize an array to store the updated tasks
        $updatedTasks = array();

        // Loop through the completed tasks
        foreach ($completedTasks as $task) {
            // Get the task details
            $taskID = $task['taskID'];
            $listID = $task['originalListID']; // Get the original list ID
            $type = $task['type'];
            $dateAssignedTimestamp = strtotime($task['dateAssigned']);

            // Calculate the next date assigned based on the task type
            switch ($type) {
                case 1: // Repeat daily
                    // Set the next date to 1 day after the original date assigned
                    $nextDateAssignedTimestamp = strtotime('+1 day', $dateAssignedTimestamp);
                    break;

                case 2: // Repeat daily without weekends
                    // Skip weekends and set the next date to the start of the next weekday (Monday)
                    $nextDateAssignedTimestamp = strtotime('+1 weekday', $dateAssignedTimestamp);
                    break;

                case 3: // Repeat weekly
                    // Set the next date to 1 week after the original date assigned
                    $nextDateAssignedTimestamp = strtotime('+1 week', $dateAssignedTimestamp);
                    break;

                case 4: // Repeat monthly
                    // Set the next date to 1 month after the original date assigned
                    $nextDateAssignedTimestamp = strtotime('+1 month', $dateAssignedTimestamp);
                    break;

                case 5: // Repeat yearly
                    // Set the next date to 1 year after the original date assigned
                    $nextDateAssignedTimestamp = strtotime('+1 year', $dateAssignedTimestamp);
                    break;

                default:
                    // Skip if the type is not valid (0 or others)
                    continue 2;
            }

            // Check if the next date assigned is in the future
            if ($nextDateAssignedTimestamp > $currentTimestamp) {
                // Update the task with the next date assigned and move it back to the original list
                $nextDateAssigned = date('Y-m-d H:i:s', $nextDateAssignedTimestamp);
                $this->moveTaskToOriginalList($taskID, $listID, $nextDateAssigned);

                // Add the updated task to the array
                $updatedTasks[] = array(
                    'taskID' => $taskID,
                    'listID' => $listID,
                    'nextDateAssigned' => $nextDateAssigned,
                    'type' => $type,
                    'originalListID' => $task['originalListID'],
                );
            } else {
                // If the next date assigned is in the past, remove the task from the CompletedTasksList
                $this->deleteTask($userID, $this->getCompletedTasksListID($userID), $taskID);
            }
        }

        // Check if there are any updated tasks
        if (count($updatedTasks) > 0) {
            return array('success' => 'Repeating tasks updated successfully.', 'updatedTasks' => $updatedTasks);
        } else {
            return array('message' => 'No repeating tasks were updated.');
        }
    }





    // Function to delete a task
    public function deleteTask($userID, $listID, $taskID)
    {
        // Check if the taskID belongs to this list
        if (!$this->taskExistsForList($taskID, $listID)) {
            return false; // The specified task does not belong to this list
        }

        // Check if the task is in the recycleBin or CompletedTasksList
        $listName = $this->getListNameByID($listID);
        if ($listName === 'recycleBin' || $listName === 'CompletedTasksList') {
            // Permanently delete the task from the database
            $query = 'DELETE FROM task WHERE listID = ? AND taskID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $listID, $taskID);

            if ($stmt->execute()) {
                return true; // Task deleted successfully
            } else {
                return false; // Failed to delete task
            }
        } else {
            // Move the task to the recycleBin
            $recycleBinListID = $this->getRecycleBinListID($userID); // Get the recycleBin listID

            if ($recycleBinListID === null) {
                return false; // Recycle bin list not found
            }

            $query = 'UPDATE task SET listID = ? WHERE taskID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $recycleBinListID, $taskID);

            if ($stmt->execute()) {
                return true; // Task moved to recycleBin successfully
            } else {
                return false; // Failed to move task to recycleBin
            }
        }
    }

    public function deleteTask2($userID, $listID, $taskID)
    {
        // Check if the taskID belongs to this list
        if (!$this->taskExistsForList($taskID, $listID)) {
            return false; // The specified task does not belong to this list
        }

        
            $query = 'DELETE FROM task WHERE listID = ? AND taskID = ?';
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $listID, $taskID);

            if ($stmt->execute()) {
                return true; // Task deleted successfully
            } else {
                return false; // Failed to delete task
            }
        
    }


    // Function to get all tasks in a list
    public function getListTasks($listID)
    {
        $query = 'SELECT * FROM task WHERE listID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $listID);
        $stmt->execute();
        $result = $stmt->get_result();

        $tasks = array();
        while ($row = $result->fetch_assoc()) {
            $tasks[] = $row;
        }

        return $tasks;
    }

    // Function to get details of a single task
    public function getSingleTask($taskID)
    {
        $query = 'SELECT * FROM task WHERE taskID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $taskID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            return ['error' => 'Task not found.'];
        }

        $task = $result->fetch_assoc();
        return $task;
    }

    // Function to update a task
    public function updateTask($taskID, $dateAssigned = null, $type = null, $prio = null, $taskText = null)
    {
        $task = $this->getSingleTask($taskID);
        if (isset($task['error'])) {
            return ['error' => 'Task not found.'];
        }

        // Initialize an empty array to store the fields and values to be updated
        $updateFields = array();

        // Check each parameter and add it to the updateFields array if provided


        if ($dateAssigned !== null) {
            // Validate dateAssigned (should be after the current timestamp)
            $currentTimestamp = time();
            $dateAssignedTimestamp = strtotime($dateAssigned);
            if ($dateAssignedTimestamp === false || $dateAssignedTimestamp < $currentTimestamp) {
                return ['error' => 'Invalid value for dateAssigned. It should be a date after the current time.'];
            }
            $updateFields[] = 'dateAssigned = "' . $this->conn->real_escape_string($dateAssigned) . '"';
        }

        if ($type !== null) {
            // Validate type (should be an integer between 0 and 5)
            if (!is_int($type) || $type < 0 || $type > 5) {
                return ['error' => 'Invalid value for type. It should be an integer between 0 and 5.'];
            }
            $updateFields[] = 'type = ' . intval($type);
        }

        if ($prio !== null) {
            // Validate prio (should be an integer between 1 and 5)
            if (!is_int($prio) || $prio < 1 || $prio > 5) {
                return ['error' => 'Invalid value for prio. It should be an integer between 1 and 5.'];
            }
            $updateFields[] = 'prio = ' . intval($prio);
        }

        if ($taskText !== null) {
            $updateFields[] = 'taskText = "' . $this->conn->real_escape_string($taskText) . '"';
        }

        // If no valid fields to update, return an error
        if (count($updateFields) === 0) {
            return ['error' => 'No valid fields to update.'];
        }

        // Construct the update query dynamically
        $query = 'UPDATE task SET ' . implode(', ', $updateFields) . ' WHERE taskID = ?';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $taskID);

        if ($stmt->execute()) {
            return ['success' => 'Task updated successfully.'];
        } else {
            return ['error' => 'Failed to update task.'];
        }
    }
}
