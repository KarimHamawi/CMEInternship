<?php
$db_host = '127.0.0.1';
$db_user = 'root';
$db_password = '';
$db_name = 'todolistdb';

try {
    // Create a new mysqli object
    $db = new mysqli($db_host, $db_user, $db_password, $db_name);

    // Set some db attributes
    $db->set_charset("utf8");
    $db->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, true);

    // Define your application name
    define('APP_NAME', 'todolistapp');

    http_response_code(200); // OK
} catch (mysqli_sql_exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(array('message' => 'Failed to connect to the database.'));
    exit;
}
?>