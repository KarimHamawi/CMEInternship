<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Instantiate the Tasks class
$tasks = new Tasks($db);

// Call the function to update repeating tasks
$response = $tasks->deleteExpiredTask($userID);

// Echo the result
echo json_encode($response);
?>