<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the Tasks class
$tasks = new Tasks($db);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Check if listID is provided and valid
$listID = $_SESSION['list_id'] ?? null;
if (!$listID) {
    echo json_encode(array('error' => 'No list currently accessed.'));
    exit;
} elseif (!is_int($listID) || $listID <= 0) {
    echo json_encode(array('error' => 'Invalid listID. It should be a positive integer.'));
    exit;
}

// Check if the list belongs to the user
$listName = $tasks->listExistsForUser($listID, $userID);
if (!$listName) {
    echo json_encode(array('error' => 'The specified list does not belong to this user.'));
    exit;
}

// Get all the tasks for the given listID from the database
$listTasks = $tasks->getListTasks($listID);

if (!empty($listTasks)) {
    // Tasks retrieved successfully
    echo json_encode($listTasks);
} else {
    // No tasks for the list
    echo json_encode(array('message' => 'No tasks found for the list.'));
}
?>