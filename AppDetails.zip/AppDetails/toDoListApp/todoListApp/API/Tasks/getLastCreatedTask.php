<?php
session_start();

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');

include_once('../../core/initialize.php');

$tasks = new Tasks($db);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

$_SESSION['last_activity'] = time();
$userID = $_SESSION['user_id'];
$listID = $_SESSION['list_id'] ?? null;

if (!$listID) {
    echo json_encode(array('error' => 'No list currently accessed.'));
    exit;
}

if (!$tasks->listExistsForUser($listID, $userID)) {
    echo json_encode(array('error' => 'List does not belong to the user or does not exist.'));
    exit;
}

$lastTaskDetails = $tasks->getLastCreatedTask($listID);

if ($lastTaskDetails) {
    echo json_encode(['success' => true, 'task' => $lastTaskDetails]);
} else {
    echo json_encode(array('error' => 'Failed to get last created task.'));
}
?>
