<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the Tasks class
$tasks = new Tasks($db);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in
    echo json_encode(array('error' => 'User not logged in.'));
    exit; // Stop further execution
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Check if the list_id is in the session
if (!isset($_SESSION['list_id'])) {
    // list_id is not in the session
    echo json_encode(array('error' => 'list is not currently accessed.'));
    exit; // Stop further execution
}

// Check if the required fields are provided
$data = json_decode(file_get_contents("php://input"));
if (!isset($data->taskText) || !isset($data->dateAssigned)) {
    // Required fields not provided
    echo json_encode(array('error' => 'taskText and dateAssigned are required.'));
    exit; // Stop further execution
}

// Set task data from the input and session
$userID = $_SESSION['user_id'];
$listID = $_SESSION['list_id'];
$taskText = $data->taskText;
$dateAssigned = $data->dateAssigned;

// Check if the listName belongs to the recycleBin or CompletedTasksList
$listName = $tasks->getListNameByID($listID);
if ($listName === 'recycleBin' || $listName === 'CompletedTasksList') {
    echo json_encode(array('error' => 'Cannot create tasks in recycleBin or CompletedTasksList.'));
    exit;
}

// Validate and set type as integer (should be an integer between 0 and 5)
$type = isset($data->type) ? filter_var($data->type, FILTER_VALIDATE_INT) : null;
if ($type === false || ($type !== null && ($type < 0 || $type > 5))) {
    echo json_encode(array('error' => 'Invalid value for type. It should be an integer between 0 and 5.'));
    exit;
}

// Validate and set prio as integer (should be an integer between 1 and 5)
$prio = isset($data->prio) ? filter_var($data->prio, FILTER_VALIDATE_INT) : null;
if ($prio === false || ($prio !== null && ($prio < 1 || $prio > 5))) {
    echo json_encode(array('error' => 'Invalid value for prio. It should be an integer between 1 and 5.'));
    exit;
}

if (is_null($taskText) || trim($taskText) === '') {
    echo json_encode(array('error' => 'Task text cannot be empty or just spaces.'));
    exit;
}

// Create the task in the database
$result = $tasks->createSingleTask($userID, $listID, $taskText, $dateAssigned, $type, $prio);

if (isset($result['success'])) {
    // Task creation successful
    echo json_encode($result);
} elseif (isset($result['error'])) {
    // Failed to create task
    echo json_encode($result);
} else {
    // Failed to create task
    echo json_encode(array('error' => 'Failed to create task.'));
}
?>