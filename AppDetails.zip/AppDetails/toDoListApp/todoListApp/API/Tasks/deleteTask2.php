<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Check if listID and taskID are provided
$data = json_decode(file_get_contents("php://input"));
if (!isset($data->taskID) || !filter_var($data->taskID, FILTER_VALIDATE_INT) || $data->taskID <= 0) {
    echo json_encode(array('error' => 'Invalid taskID. It should be a positive integer.'));
    exit;
}

// Set taskID from the input
$taskID = $data->taskID;

// Instantiate the Tasks class
$tasks = new Tasks($db);

// Check if the listID exists and belongs to the user
$listID = $_SESSION['list_id'] ?? null;
if (!$listID) {
    echo json_encode(array('error' => 'No list currently accessed.'));
    exit;
}

$listName = $tasks->listExistsForUser($listID, $userID);
if (!$listName) {
    echo json_encode(array('error' => 'The specified list does not belong to this user.'));
    exit;
}

// Check if the taskID belongs to this list
if (!$tasks->taskExistsForList($taskID, $listID)) {
    echo json_encode(array('error' => 'The specified task does not belong to this list.'));
    exit;
}

// Delete the task from the database
$deleted = $tasks->deleteTask2($userID, $listID, $taskID);

if ($deleted) {
    // Task deleted successfully
    echo json_encode(array('success' => 'Task deleted successfully.'));
} else {
    // Failed to delete task
    echo json_encode(array('error' => 'Failed to delete task.'));
}
?>