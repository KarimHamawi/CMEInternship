<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Get the list ID from the session
$listID = $_SESSION['list_id'] ?? null;
if (!$listID) {
    echo json_encode(array('error' => 'No list currently accessed.'));
    exit;
} elseif (!is_int($listID) || $listID <= 0) {
    echo json_encode(array('error' => 'Invalid listID. It should be a positive integer.'));
    exit;
}

// Instantiate the Tasks class
$tasks = new Tasks($db);

// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

// Check if taskID is provided and validate as integer
if (!isset($data->taskID) || !filter_var($data->taskID, FILTER_VALIDATE_INT) || $data->taskID <= 0) {
    echo json_encode(array('error' => 'Invalid taskID. It should be a positive integer.'));
    exit;
}

// Set taskID from the input
$taskID = $data->taskID;

// Check if the task belongs to this list
$task = $tasks->getSingleTask($taskID);
if (isset($task['error'])) {
    echo json_encode(array('error' => 'Task not found.'));
    exit;
}

if ($task['listID'] != $listID) {
    echo json_encode(array('error' => 'The specified task does not belong to this list.'));
    exit;
}

// Check if the task is in recycleBin or CompletedTasksList
if ($tasks->isTaskInSpecialList($taskID)) {
    echo json_encode(array('error' => 'Cannot update tasks in recycleBin or CompletedTasksList.'));
    exit;
}

// Validate and set type as integer (should be an integer between 0 and 5)
$type = isset($data->type) ? filter_var($data->type, FILTER_VALIDATE_INT) : null;
if ($type === false || ($type !== null && ($type < 0 || $type > 5))) {
    echo json_encode(array('error' => 'Invalid value for type. It should be an integer between 0 and 5.'));
    exit;
}

// Validate and set prio as integer (should be an integer between 1 and 5)
$prio = isset($data->prio) ? filter_var($data->prio, FILTER_VALIDATE_INT) : null;
if ($prio === false || ($prio !== null && ($prio < 1 || $prio > 5))) {
    echo json_encode(array('error' => 'Invalid value for prio. It should be an integer between 1 and 5.'));
    exit;
}

if (is_null($data->taskText) || trim($data->taskText) === '') {
    echo json_encode(array('error' => 'Task text cannot be empty or just spaces.'));
    exit;
}


// Update the task in the database
$updatedTask = $tasks->updateTask($taskID, $data->dateAssigned, $type, $prio, $data->taskText);

// Echo the result of the updateTask function
echo json_encode($updatedTask);
?>
