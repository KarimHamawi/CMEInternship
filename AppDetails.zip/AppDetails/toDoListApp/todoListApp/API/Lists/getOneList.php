<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the Lists class
$lists = new Lists($db);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Check if list ID is provided and is an integer
$listID = $_SESSION['list_id'];

// Check if list ID is a valid integer
if ($listID === false || $listID === null) {
    echo json_encode(array('error' => 'Invalid List ID. It should be an integer.'));
    exit;
}

// Check if the list ID is valid for the user
if (!$lists->listExistsForUser($listID, $userID)) {
    echo json_encode(array('error' => 'List not found for this User.'));
    exit;
}

$result = $lists->getOneList($listID);


// Return success response
echo json_encode($result);
?>