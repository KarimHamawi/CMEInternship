<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Get the list ID from the session
$listID = $_SESSION['list_id'] ?? null;
if (!$listID) {
    echo json_encode(array('error' => 'No list currently accessed.'));
    exit;
}

// Instantiate the Lists class
$lists = new Lists($db);

// Delete the list
$result = $lists->deleteList($userID, $listID);

// Echo the result of the deleteList function
echo json_encode($result);
?>