<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the Lists class
$lists = new Lists($db);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Get all lists for the user
$userLists = $lists->getAllUserLists($userID);

// Check if the user has any lists
if (empty($userLists)) {
    echo json_encode(array('error' => 'No lists found for the user.'));
} else {
    echo json_encode($userLists);
}
?>