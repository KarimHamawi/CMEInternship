<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the Lists class
$lists = new Lists($db);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in
    echo json_encode(array('error' => 'User not logged in.'));
    exit; // Stop further execution
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Check if the required fields are provided
$data = json_decode(file_get_contents("php://input"));


if (!isset($data->listName)) {


    // Required fields not provided
    echo json_encode(array('error' => 'listName is required.'));
    exit; // Stop further execution
}

// Set list data from the input and session
$userID = $_SESSION['user_id'];
$listName = $data->listName;
$sortingPref = isset($data->sortingPref) ? filter_var($data->sortingPref, FILTER_VALIDATE_INT) : null;

// Validate sortingPref (should be null, 0, or 1)
if ($sortingPref !== null && ($sortingPref !== 0 && $sortingPref !== 1)) {
    echo json_encode(array('error' => 'Invalid value for sortingPref. It should be null, 0, or 1.'));
    exit;
}

if (is_null($listName) || trim($listName) === '') {
    echo json_encode(array('error' => 'List name cannot be empty or just spaces.'));
    exit;
}

// Create the list in the database
$result = $lists->createList($userID, $listName, $sortingPref);



if (isset($result['success'])) {

    // List creation successful
    echo json_encode($result);

} elseif (isset($result['error'])) {

    // Failed to create list
    echo json_encode($result);
    
} else {
    // Failed to create list
    echo json_encode(array('error' => 'Failed to create list.'));
}
?>