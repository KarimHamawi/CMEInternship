<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID and list ID from the session
$userID = $_SESSION['user_id'];
$listID = $_SESSION['list_id'] ?? null;

// Check if the list ID is valid
if (!$listID) {
    echo json_encode(array('error' => 'No list currently accessed.'));
    exit;
} elseif (!filter_var($listID, FILTER_VALIDATE_INT) || $listID <= 0) {
    echo json_encode(array('error' => 'Invalid listID. It should be a positive integer.'));
    exit;
}

// Instantiate the Lists class
$lists = new Lists($db);

// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

$listName = $data->listName ?? null;

// Validate listName
if (is_null($listName) || trim($listName) === '') {
    echo json_encode(array('error' => 'List name cannot be empty or just spaces.'));
    exit;
}

// Validate and set sortingPref as integer (should be 0 or 1)
$sortingPref = isset($data->sortingPref) ? filter_var($data->sortingPref, FILTER_VALIDATE_INT) : null;

// Check if sortingPref is provided and is a valid integer value (0 or 1)
if ($sortingPref !== null && ($sortingPref !== 0 && $sortingPref !== 1)) {
    echo json_encode(array('error' => 'Invalid value for sortingPref. It should be 0 or 1.'));
    exit;
}


// Update the list in the database
$result = $lists->updateList($userID, $listID, $listName, $sortingPref);

if (isset($result['success'])) {
    // List update successful
    echo json_encode($result);
} elseif (isset($result['error'])) {
    // Failed to update list
    echo json_encode($result);
} else {
    // No valid fields to update
    echo json_encode(array('error' => 'No valid fields to update.'));
}
?>