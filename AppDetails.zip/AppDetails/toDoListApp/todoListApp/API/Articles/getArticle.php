<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');

// Initialize our API
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Instantiate the Articles class
$articles = new Articles($db);

// Get the points of the logged-in user
$userPoints = $articles->getUserPoints($userID);

// Define the article directory
$articleDirectory = 'C:/xampp/htdocs/toDoListApp/todoListApp/txtFiles/';
$articleFile = '';

// Determine the article file based on user points
if ($userPoints < 10) {
    $articleFile = 'article1.txt';
} elseif ($userPoints >= 10 && $userPoints < 20) {
    $articleFile = 'article2.txt';
} elseif ($userPoints >= 20 && $userPoints < 30) {
    $articleFile = 'article3.txt';
} elseif ($userPoints >= 30 && $userPoints < 40) {
    $articleFile = 'article4.txt';
} elseif ($userPoints >= 40 && $userPoints < 50) {
    $articleFile = 'article5.txt';
} elseif ($userPoints >= 50 && $userPoints < 60) {
    $articleFile = 'article6.txt';
} elseif ($userPoints >= 60 && $userPoints < 70) {
    $articleFile = 'article7.txt';
} elseif ($userPoints >= 70 && $userPoints < 80) {
    $articleFile = 'article8.txt';
} elseif ($userPoints >= 80 && $userPoints < 90) {
    $articleFile = 'article9.txt';
} elseif ($userPoints >= 90) {
    $articleFile = 'article10.txt';
}


// Read the content of the article file
$articleContent = file_get_contents($articleDirectory . $articleFile);

// Check if the file was read successfully
if ($articleContent !== false) {
    echo json_encode(array('article' => $articleContent, 'userPoints' => $userPoints));
} else {
    echo json_encode(array('error' => 'Failed to read the article.'));
}
?>