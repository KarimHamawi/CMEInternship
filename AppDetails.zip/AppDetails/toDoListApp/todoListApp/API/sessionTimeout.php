<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Get the last activity time of the session
$lastActivityTime = $_SESSION['last_activity'] ?? 0;

// Set the maximum allowed idle time (in seconds) before session timeout
$maxIdleTimeSeconds = 600;

// Check if the session has timed out
if (time() - $lastActivityTime > $maxIdleTimeSeconds) {
    
    // Destroy the session and log out the user
    session_unset();
    session_destroy();
    echo json_encode(array('message' => 'Session timed out. User logged out.'));
    exit;
}


// Return success response
echo json_encode(array('message' => 'Session active.'));
?>