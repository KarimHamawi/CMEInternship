<?php
// session
session_start();
//headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
//initialize our api
include_once('../../core/initialize.php');

//instantiate user
$user = new userWithSettings($db);

// Get userID from the session variable
$userID = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : die(json_encode(array('error' => 'User not logged in.')));

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get user settings based on the userID
$result = $user->getSettings($userID);

// Check if the user exists
if (isset($result['error'])) {

    // User not found, return an error response
    echo json_encode(array('error' => 'User not found.'));
} else {
    
    // User found, return the settings
    echo json_encode($result);
}
?>