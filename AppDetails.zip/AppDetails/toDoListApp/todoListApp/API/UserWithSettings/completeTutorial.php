<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');

// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the UserwithSettings class
$user = new UserwithSettings($db);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User is not logged in.'));
    exit;
}

// Toggle the tutorial completion status for the logged-in user
$newStatus = $user->completeTutorial($_SESSION['user_id']);

// Send a response based on the result
if($newStatus !== false) {
    echo json_encode(array('message' => 'Tutorial status toggled.', 'newStatus' => ($newStatus == 1 ? "completed" : "incomplete")));
} else {
    echo json_encode(array('error' => 'Failed to toggle tutorial status.'));
}
?>
