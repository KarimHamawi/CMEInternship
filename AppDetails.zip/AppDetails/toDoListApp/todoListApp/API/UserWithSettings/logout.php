<?php
session_start();

//headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
date_default_timezone_set('Asia/Beirut');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Return a success message
    echo json_encode(array('success' => 'Logout successful.'));
} else {
    // If the user is not logged in, return an error message
    echo json_encode(array('error' => 'User not logged in.'));
}
?>