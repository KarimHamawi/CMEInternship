<?php
session_start();

// headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// initialize our api
include_once('../../core/initialize.php');

// instantiate user
$user = new UserwithSettings($db);


// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    session_destroy();
}

// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

// Check if email and password are provided and not empty
if (!isset($data->email) || empty($data->email) || !isset($data->password) || empty($data->password)) {
    echo json_encode(array('error' => 'Email and password are required.'));
    exit;
}

// Login the user
$result = $user->login($data->email, $data->password);

// Check if login was successful
if (isset($result['error'])) {
    
    // Login failed, return an error response
    echo json_encode(array('error' => $result['error']));
} else {


    // Update the last_activity session variable to the current timestamp
    $_SESSION['last_activity'] = time();

    // Login successful, set the user ID in the session variable for future use
    $_SESSION['user_id'] = $result['userID'];
    $_SESSION['list_id'] = $user->getPreferredList($result['userID']);

  if($result['tutorialCompletion'] == 0) {
    echo json_encode(array('message' => 'You have successfully logged in.', 'tutorialStatus' => 'incomplete'));
} else {
    echo json_encode(array('message' => 'You have successfully logged in.', 'tutorialStatus' => 'complete'));
}

}
?>