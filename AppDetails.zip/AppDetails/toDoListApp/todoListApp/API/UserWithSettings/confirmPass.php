<?php
session_start();

// headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// initialize our api
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// instantiate user
$user = new UserwithSettings($db);

// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

// Check if email and password are provided and not empty
if (!isset($data->password) || empty($data->password)) {
    echo json_encode(array('error' => 'Password is required.'));
    exit;
}

// Login the user
$result = $user->confirm($data->password, $userID);

// Check if login was successful
if (isset($result['error'])) {
    // Login failed, return an error response
    echo json_encode(array('error' => $result['error']));
} else {

    echo json_encode(array('success' => 'You have successfully confirmed the password.'));

}
?>