<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Instantiate the UserwithSettings class
$user = new UserwithSettings($db);

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    session_destroy();
}



// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->isTemporary) || !filter_var($data->isTemporary, FILTER_VALIDATE_INT) || ($data->isTemporary != 0 && $data->isTemporary != 1)) {
    $isTemporary = 0; // Default value if validation fails
} else {
    $isTemporary = $data->isTemporary;
}
// Check if the required fields are provided
if (
    !empty($data->fullName) &&
    !empty($data->email) &&
    !empty($data->password)
) {
    // Set user data from the input
    $fullName = $data->fullName;
    $email = $data->email;
    $password = $data->password;

    // Create the user in the database and get the generated userID
    $userID = $user->signup($fullName, $email, $password, $isTemporary);

    if (isset($userID['success'])) {
        // Update the last_activity session variable to the current timestamp
        $_SESSION['last_activity'] = time();
    }

    echo json_encode($userID);

} else {
    // Required fields not provided
    echo json_encode(array('error' => 'Full name, email, and password are required.'));
}
?>