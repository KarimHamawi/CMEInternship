<?php
// Start session
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize API
include_once('../../core/initialize.php');

// Instantiate userWithSettings
$user = new userWithSettings($db);

// Get userID from the session variable
$userID = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : die(json_encode(array('error' => 'User not logged in.')));

// Update the last_activity session variable to the current timestamp
$_SESSION['last_activity'] = time();

// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

// Prepare variables with default values
$fullName = $data->fullName ?? null;
$password = $data->password ?? null;

// Validate and set emailDecision (should be an integer)
$emailDecision = isset($data->emailDecision) ? filter_var($data->emailDecision, FILTER_VALIDATE_INT) : null;
if ($emailDecision === false) {
    echo json_encode(array('error' => 'Invalid value for emailDecision. It should be an integer.'));
    exit;
}

// Validate and set reminderTiming (should be an integer)
$reminderTiming = isset($data->reminderTiming) ? filter_var($data->reminderTiming, FILTER_VALIDATE_INT) : null;
if ($reminderTiming === false) {
    echo json_encode(array('error' => 'Invalid value for reminderTiming. It should be an integer.'));
    exit;
}

// Validate and set preferredList (should be an integer)
$preferredList = isset($data->preferredList) ? filter_var($data->preferredList, FILTER_VALIDATE_INT) : null;
if ($preferredList === false) {
    echo json_encode(array('error' => 'Invalid value for preferredList. It should be an integer.'));
    exit;
}

// Validate and set recycleBinDecision (should be an integer)
$recycleBinDecision = isset($data->recycleBinDecision) ? filter_var($data->recycleBinDecision, FILTER_VALIDATE_INT) : null;
if ($recycleBinDecision === false) {
    echo json_encode(array('error' => 'Invalid value for recycleBinDecision. It should be an integer.'));
    exit;
}

// Update user settings
$result = $user->updateSettings($userID, $fullName, $password, $emailDecision, $reminderTiming, $preferredList, $recycleBinDecision);

// Check if the update was successful
if (isset($result['error'])) {
    // User not found, return an error response
    echo json_encode($result);
} elseif (isset($result['success'])) {
    // Settings updated successfully, return a success response
    echo json_encode(array('message' => 'Settings updated successfully.'));
} else {
    // Failed to update settings, return an error response
    echo json_encode(array('error' => 'Failed to update settings.'));
}
?>