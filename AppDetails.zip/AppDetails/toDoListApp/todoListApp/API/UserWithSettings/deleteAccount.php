<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// Initialize our API
include_once('../../core/initialize.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(array('error' => 'User not logged in.'));
    exit;
}

// Get the user ID from the session
$userID = $_SESSION['user_id'];

// Instantiate the UserwithSettings class
$user = new UserwithSettings($db);

// Call the deleteAccount function to delete the user's account, lists, and tasks
$response = $user->deleteAccount($userID);

// Kill the entire session
session_destroy();

// Return the response from the deleteAccount function
echo json_encode($response);
?>