<?php
session_start();

// headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: text/html');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');
// initialize our api
include_once('../../core/initialize.php');

// Instantiate the UserwithSettings class
$user = new UserwithSettings($db);

function outputMessage($message)
{
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Password Reset</title>
        <link href='https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap' rel='stylesheet'>
        <style>
            body {
                font-family: 'Roboto', sans-serif;
                display: flex;
                height: 100vh;
                align-items: center;
                justify-content: center;
                background: linear-gradient(45deg, #f5f5f5, #e0e0e0);
                margin: 0;
            }
            
            .container {
                width: 100%;
                max-width: 400px;
                padding: 30px;
                background-color: #ffffff;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
                border-radius: 10px;
                text-align: center;
                transition: all 0.3s ease;
            }
            
            .container:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            }
            
            .message {
                color: #555;
                font-size: 18px;
                margin-bottom: 20px;
            }
            
            a {
                display: inline-block;
                padding: 10px 20px;
                border-radius: 5px;
                background-color: #007bff;
                color: #ffffff;
                font-weight: 500;
                text-decoration: none;
                transition: background-color 0.3s ease;
            }
            
            a:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>Password Reset</h2>
            <p class='message'>{$message}</p>
            <p><a href='http://localhost/toDoListApp/todoListApp/FrontEnd/index.html'>Return to Login</a></p>
        </div>
    </body>
    </html>";
}


if (isset($_GET['data'])) {
    $data = $_GET['data'];

    // Decrypt the data
    list($encryptedEmail, $encryptedToken, $encryptedIv) = explode(':', $data);

    $cipher = "aes-128-cbc";
    $key = "your_secure_encryption_key"; // Replace with your own secure key
    $iv = base64_decode(urldecode($encryptedIv));

    $email = openssl_decrypt(base64_decode(urldecode($encryptedEmail)), $cipher, $key, 0, $iv);
    $resetToken = openssl_decrypt(base64_decode(urldecode($encryptedToken)), $cipher, $key, 0, $iv);

    // Look up the token in the database
    $query = 'SELECT * FROM password_resets WHERE email = ? AND token = ?';
    $stmt = $db->prepare($query);
    $stmt->bind_param('ss', $email, $resetToken);
    $stmt->execute();
    $result = $stmt->get_result();


    if ($row = $result->fetch_assoc()) {
        $expires_at = new DateTime($row['expires_at']);
        $now = new DateTime('now');

        if ($now < $expires_at) {
            // Token is valid and not expired: proceed with password reset
            $hashedPassword = password_hash($resetToken, PASSWORD_DEFAULT);

            // Update the user's password in the database
            $query = 'UPDATE user SET password = ? WHERE email = ?';
            $stmt = $db->prepare($query);
            $stmt->bind_param('ss', $hashedPassword, $email);

            if ($stmt->execute()) {
                // Password update successful
                // ... (Your existing code to handle a successful password update)
                outputMessage('You have successfully changed your password. Try logging in again.');
            } else {
                // Password update failed
                outputMessage('Failed to reset your password.');
            }

        } else {
            outputMessage('The reset token has expired.');
            $deleteQuery = 'DELETE FROM password_resets WHERE email = ? AND token = ?';
            $deleteStmt = $db->prepare($deleteQuery);
            $deleteStmt->bind_param('ss', $email, $resetToken);
            $deleteStmt->execute();
        }
    } else {
        outputMessage('Invalid reset token.');
    }
    $deleteQuery = 'DELETE FROM password_resets WHERE expires_at < NOW()';
    $db->query($deleteQuery);
} else {
    // Invalid URL parameters
    outputMessage('Invalid URL parameters.');
}
?>