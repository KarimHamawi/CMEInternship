<?php
session_start();

//headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
date_default_timezone_set('Asia/Beirut');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {


    echo json_encode(array('success' => 'Logged in.'));
} else {
    
    // If the user is not logged in, return an error message
    echo json_encode(array('error' => 'User not logged in.'));
    session_destroy();
}
?>