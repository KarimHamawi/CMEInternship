<?php
session_start();

// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');
date_default_timezone_set('Asia/Beirut');

// Initialize our API
include_once('../../core/initialize.php');


// Instantiate the UserwithSettings class
$user = new UserwithSettings($db);

if (isset($_SESSION['user_id'])) {
    session_destroy();
}

// Get raw posted data
$data = json_decode(file_get_contents("php://input"));

// Check if the required fields are provided
if (
    !empty($data->email)
) {
    // Set user data from the input
    $email = $data->email;

    $response = $user->forgotPassword($email);
} else {
    echo json_encode(array('error' => 'Email is required!'));
    exit;
}

// Echo the result
echo json_encode($response);
?>